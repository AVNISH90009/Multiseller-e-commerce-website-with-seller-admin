<?php
require('includes/common.inc.php');

if(isset($_GET['a']) && $_GET['a']!=''){
   $a = getSafeValue($con,$_GET['a']);
   if ($a == 'delete'){
       $id = getSafeValue($con,$_GET['id']);
       $del_sql= "delete from contact us where id = '$id'";
       mysqli_query($con,$del_sql);
   }
}

$sql="select * from contact_us order by id desc";
$res=mysqli_query($con,$sql);

?>

<style>
  body{
    /*background-color: #87ceeb20;*/
    background-color: #aa207f30;
  }
  .card{
    /*border: 1px solid #87ceeb;*/
    border: 1px solid #aa207f00!important;
    box-shadow: 0 0 15px 0px #aaaaaa99;
  }

   h6.light-grey{
      color:#7a7a7a!important;
      font-size:12px;
      padding:0;
      margin:0;
   }
   h6.b-black{
      color:#000000!important;
      font-size:12px;
      padding:0;
      margin:0;
   }

   h6.small-black{
      
      font-size:13px;
      padding:0;
      margin-top:8px;
   }
   .noborder{
      border:none;
   }

</style>

<div class="container-fluid" style="padding: 100px 30px 30px 30px;">

  <div class="container-fluid">
    <div class="card mb-3">
      <div class="card-body">
        <h5 class="card-title">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb" style="background-color:rgba(0,0,0,0)!important;">
              <li class="breadcrumb-item active" aria-current="page"
                style="color: #000000; padding-top:10px; padding-left:10px; Font-size: 25px">Converstions</li>
            </ol>
          </nav>
        </h5>
      </div>
    </div>
  </div>
   
      <div class="container-fluid">
         <div class="content pb-0">
            <div class="orders">
               <div class="row">
                  <div class="col-xl-12">
                     <div class="card">
                        <div class="card-body">
                        </div>
                        <div class="card-body--">
                           <div class="container-fluid">
                           <div class="table-stats order-table ov-h">
                              <table class="table ">
                                 <thead>
                                    <tr>
                                       <th class="serial">#</th>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Query</th>
                                        <th>Date</th>
                                        <th></th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                     <?php
                                     $i = 1;
                                     while($row = mysqli_fetch_assoc($res)){?>
                                    <tr>
                                        <td class="serial"><?php echo $i?></td>
                                        <td><?php echo $row['id']?></td>
                                        <td><?php echo $row['name']?></td>
                                        <td><?php echo $row['email']?></td>
                                        <td><?php echo $row['phone_no']?></td>
                                        <td><?php echo $row['comment']?></td>
                                        <td><?php echo $row['time']?></td>
                                        <td>
                                        <?php
								echo "<span class='badge badge-delete'><a href='?a=delete&id=".$row['id']."'>Delete</a></span>";
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
</div>                                
</div>
</div>

<?php
require('includes/footer.inc.php');
?>