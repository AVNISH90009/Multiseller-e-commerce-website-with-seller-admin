<?php
require('includes/common.inc.php');
$def_id = $_SESSION['default_id'];

$sql_product_listing_active = "SELECT * FROM product WHERE status = 1 AND default_id = $def_id;";
$product_listing_active = mysqli_query($con,$sql_product_listing_active);
$count_active_products = mysqli_num_rows($product_listing_active);

$sql_product_listing_inactive = "SELECT * FROM product WHERE status = 0 AND default_id = $def_id;";
$product_listing_inactive = mysqli_query($con,$sql_product_listing_inactive);
$count_inactive_products = mysqli_num_rows($product_listing_inactive);

$new_order_sql = "SELECT DISTINCT * FROM orders, products_ordered WHERE products_ordered.default_seller_id = $def_id AND products_ordered.order_id=orders.order_id";
$new_orders = mysqli_query($con,$new_order_sql);
$total_orders=0;
while($tot_ord=mysqli_fetch_assoc($new_orders)){
  $ord_qty=$tot_ord['product_quantity'];
  $total_orders+=$ord_qty;
}
$new_orders_counts = mysqli_num_rows($new_orders);

?>

<style>
  body{
    /*background-color: #87ceeb20;*/
    background-color: #aa207f30;
  }
  .card{
    /*border: 1px solid #87ceeb;*/
    border: 1px solid #aa207f00!important;
    box-shadow: 0 0 15px 0px #aaaaaa99;
  }
</style>

<div class="container-fluid" style="padding: 100px 30px 30px 30px;">

  <div class="container-fluid">
    <div class="card mb-3">
      <div class="card-body">
        <h5 class="card-title">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb" style="background-color:rgba(0,0,0,0)!important;">
              <li class="breadcrumb-item active" aria-current="page"
                style="color: #000000; padding-top:10px; padding-left:10px; Font-size: 25px">Dashboard</li>
            </ol>
          </nav>
        </h5>
      </div>
    </div>
  </div>

<div class="container-fluid" style="margin-top:20px">
  <div class="row">
    <div class="col-6">
      <div class="card">
        <div class="card-body">
          <table class="table">
            <tbody>
              <tr>
                <td>
                  <h5 class="card-title">New Orders</h5>
                </td>
                <td>
                  <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria"><?php echo $total_orders ?></h5>
                </td>
              </tr>
              <tr>
                <td>
                  <h5 class="card-title">Completed Orders</h5>
                </td>
                <td>
                  <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria">0
                </td>
              </tr>
            </tbody>
          </table>
          <p class="card-text">Please fulfil this order within 3 days of receive of order.</p>
        </div>
      </div>
    </div>
    <div class="col-6">
      <div class="card">
        <div class="card-body">
          <table class="table">
            <tbody>
              <tr>
                <td>
                  <h5 class="card-title">Active Product Listings</h5>
                </td>
                <td>
                  <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria">
                    <?php echo ($count_active_products); ?>
                  </h5>
                </td>
              </tr>
              <tr>
                <td>
                  <h5 class="card-title">Inactive Product Listings</h5>
                </td>
                <td>
                  <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria">
                    <?php echo ($count_inactive_products); ?>
                </td>
              </tr>
            </tbody>
          </table>
          <p class="card-text">This is your product listings summary</p>
        </div>
      </div>
    </div>
  </div>

    <div class="row" style="margin-top:20px">
      <div class="col-6">
        <div class="card">
          <div class="card-body">
            <table class="table">
              <tbody>
                <tr>
                  <td>
                    <h5 class="card-title">Total Returns</h5>
                  </td>
                  <td>
                    <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria">0</h5>
                  </td>
                </tr>
                <tr>
                  <td>
                    <h5 class="card-title">Completed Returns</h5>
                  </td>
                  <td>
                    <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria">0
                  </td>
                </tr>
              </tbody>
            </table>
            <p class="card-text">This is your Return summary.</p>
          </div>
        </div>
      </div>
      <div class="col-6">
        <div class="card">
          <div class="card-body">
            <table class="table">
              <tbody>
                <tr>
                  <td>
                    <h5 class="card-title">Electronic Payments</h5>
                  </td>
                  <td>
                    <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria">Rs. 0</h5>
                  </td>
                </tr>
                <tr>
                  <td>
                    <h5 class="card-title">COD Payments</h5>
                  </td>
                  <td>
                    <h5 class="card-title" style="color:blue; font-weight:bold; font-family: cambria">Rs. 0</h5>
                  </td>
                </tr>
              </tbody>
            </table>
            <p class="card-text">Your payments will be initiated after a payment cycle of 10 days.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
require('includes/footer.inc.php');
?>