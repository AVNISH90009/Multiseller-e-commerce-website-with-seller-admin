<?php
require('includes/connection.inc.php');

$default_id = $_POST['default_id'];
$categories_id = $_POST['categories_id'];
$title = $_POST['title'];
$sku = $_POST['sku'];
$mrp = $_POST['mrp'];
$selling_price = $_POST['selling_price'];
$qty = $_POST['qty'];
$qty_unit = $_POST['qty_unit'];
$short_desc = $_POST['short_desc'];
$description = $_POST['description'];
/*$meta_title = $_POST['meta_title'];
$meta_desc = $_POST['meta_desc'];
$meta_keyword = $_POST['meta_keyword'];*/
$status = $_POST['status'];
$weight = $_POST['weight'];
$length = $_POST['length'];
$width = $_POST['width'];
$height = $_POST['height'];

$image = $_SESSION['default_id']."_".rand(11111111,99999999)."_".$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'],'../ECOM/products_images/'.$image);

#$sql = "INSERT INTO product (default_id,categories_id,name,sku,mrp,selling_price,qty,qty_unit,short_desc,description,image,meta_title,meta_desc,meta_keyword,status,weight,length,width,height) VALUES ('$default_id','$categories_id','$name','$sku','$mrp','$selling_price','$qty','$qty_unit','$short_desc','$description','$image','$meta_title','$meta_desc','$meta_keyword','$status','$weight','$length','$width','$height');";
$sql = "INSERT INTO product (default_id,categories_id,title,sku,mrp,selling_price,qty,qty_unit,short_desc,description,image,status,weight,length,width,height) VALUES ('$default_id','$categories_id','$title','$sku','$mrp','$selling_price','$qty','$qty_unit','$short_desc','$description','$image','$status','$weight','$length','$width','$height');";
#$sql="INSERT INTO product (default_id,categories_id,sku,mrp,selling_price,qty,qty_unit,short_desc,description) VALUES ('$default_id','$categories_id','$sku','$mrp','$selling_price','$qty','$qty_unit','$short_desc','$description');";

if(mysqli_query($con,$sql))
{
    echo("Product listing has been uploaded..!");
    header("refresh:3; url = products.php");
}
else
{
    echo("listing upload failed");
    header("refresh:200; url = add_a_product.php");
}

?>