<?php
require('includes/common.inc.php');
?>

<style>
  body{
    /*background-color: #87ceeb20;*/
    background-color: #aa207f30;
  }
  .card{
    /*border: 1px solid #87ceeb;*/
    border: 1px solid #aa207f00!important;
    box-shadow: 0 0 15px 0px #aaaaaa99;
  }
</style>

<div class="container-fluid" style="padding: 100px 30px 30px 30px;">

  <div class="container-fluid">
    <div class="card mb-3">
      <div class="card-body">
        <h5 class="card-title">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb" style="background-color:rgba(0,0,0,0)!important;">
              <li class="breadcrumb-item active" aria-current="page"
                style="color: #000000; padding-top:10px; padding-left:10px; Font-size: 25px">Add a Product</li>
            </ol>
          </nav>
        </h5>
      </div>
    </div>
  </div>

    <div class="container-fluid">
      <form method="post" enctype="multipart/form-data" action="insert_add_a_product.php">
        <div class="row">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h6>1. Mandatory Information</h6> 
                    </div>  
                    <div class="card-body card-block">
                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group">
                                    <label class=" form-control-label">Product Title<b style = "color:red"> *</b></label>
                                    <input type="text" name='title' placeholder="Enter product name" class="form-control" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group">
                                    <label for="categories" class=" form-control-label">Category<b style = "color:red"> *</b></label>
                                    <select class="form-control" name="categories_id" required>
                                        <option value="">Select Category</option>
                                        <?php
                                        $res=mysqli_query($con,"select id,categories from categories order by categories asc");
                                        while($row=mysqli_fetch_assoc($res))
                                        {
                                            if($row['id']==$categories_id)
                                            {
                                                echo "<option selected value=".$row['id'].">".$row['categories']."</option>";
                                            }
                                            else
                                            {
                                                echo "<option value=".$row['id'].">".$row['categories']."</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-sm">
                                <div class="form-group">
                                    <label class=" form-control-label">SKU<b style = "color:red"> *</b></label>
                                    <input type="text" name="sku" placeholder="Enter Stock Keeping Unit Code" class="form-control" required>
                                </div>
                            </div>

                            <div class="col-sm">
                                <div class="form-group">
                                    <label class=" form-control-label">Default_user_id<b style = "color:red"></b></label>
                                    <input type="text" name="default_id" value="<?php echo $_SESSION['default_id'] ?>" class="form-control" readonly>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group">
                                    <label class=" form-control-label">MRP<b style = "color:red"> *</b></label>
                                    <input type="text" name="mrp" placeholder="Enter product mrp" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-sm">    
                                <div class="form-group">
                                    <label class=" form-control-label">Sale Price<b style = "color:red"> *</b></label>
                                    <input type="text" name="selling_price" placeholder="Enter product price" class="form-control">
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-sm">
                                <div class="form-group">
                                    <label class=" form-control-label">Inventory Count<b style = "color:red"> *</b></label>
                                    <input type="text" name="qty" placeholder="Enter inventory counts" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-sm">
                                <div class="form-group">
                                    <label class=" form-control-label">Unit of inventory count<b style = "color:red"> *</b></label>
                                    <select class="form-control" name="qty_unit">
                                        <option value="">Select Quantity Unit</option>
                                        <option>Bags</option>
                                        <option>Nos</option>
                                        <option>Lots</option>
                                        <option>Sets</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="categories" class=" form-control-label">Short Description<b style = "color:red"> *</b></label>
                            <textarea name="short_desc" placeholder="Enter product short description" class="form-control" rows=5 required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="categories" class=" form-control-label">Description<b style = "color:red"></b></label>
                            <textarea name="description" placeholder="Enter product description" class="form-control" rows=10></textarea>
                        </div>
                        
                        <!--div class="form-group">
                            <label for="categories" class=" form-control-label">Meta Title</label>
                            <textarea name="meta_title" placeholder="Enter product meta title" class="form-control"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="categories" class=" form-control-label">Meta Description</label>
                            <textarea name="meta_desc" placeholder="Enter product meta description" class="form-control"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="categories" class=" form-control-label">Meta Keyword</label>
                            <textarea name="meta_keyword" placeholder="Enter product meta keyword" class="form-control"></textarea>
                        </div-->
                        
                        
                        <center>
                       <button id="payment-button" name="submit" type="submit" class="btn btn-lg btn-default3" style="margin-top:40px">
                       <span id="payment-button-amount">Submit</span>
                       </button></center>
                       <div class="field_error"></div>
                    </div>
             </div>
          </div>

            <div class="col-lg-4">
                <div class="card"> 
                    <div class="card-header">
                        <h6>2. Main Image<b style = "color:red"> *</b></h6> 
                    </div> 
                    <div class="card-body card-block">
                        <div class="card">
                            <?php
                            $prod_img_url = "/ECOM/images/no_image.jpg";
                            /*$sql = "SELECT * FROM product WHERE default_id = '$_SESSION['default_id']'"

                            if ($image == ""){
                                $prod_img_url = "/ECOM/images/no_image.jpg";
                            }
                            else{
                                $prod_img_url = "/ECOM/products_images/leaves.png";
                            }
                            */?>
                            <img src="<?php echo $prod_img_url?>" height=275px>
                        </div>
                        <div class="form-group imput-group mb-3">
                            <label class=" form-control-label"><b style = "color:red"></b></label>
                            <input type="file" name="image" class="form-control">
                           
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top:20px">
                    <div class="card-header">
                        <h6>3. Product Listing Status</h6> 
                    </div>
                    <div class="card-body card-block">
                        <div class="form-group">
                            <label for="categories" class=" form-control-label">Status<b style = "color:red"> *</b></label>
                            <select class="form-control" name="status" required>
                                <option value="">Select Status</option>
                                <option value = 1>Active</option>
                                <option value = 0>Inactive</option>
                            </select>
                        </div>   
                    </div>
                </div>
                <div class="card" style="margin-top:20px">
                    <div class="card-header">
                        <h6>4. Product Shipping Dimensions</h6> 
                    </div>
                    <div class="card-body card-block">
                        <div class="form-group">
                            <label class=" form-control-label">Weight (kg)<b style = "color:red"></b></label>
                            <input type="text" name="weight" placeholder="Enter weight in kg" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class=" form-control-label">Dimensions (cm)<b style = "color:red"></b></label>
                            <div class="row">
                                <div class="col">
                                    <input type="text" name="length" placeholder="length" class="form-control">
                                </div>
                                <div class="col">
                                    <input type="text" name="width" placeholder="width" class="form-control">
                                </div>
                                <div class="col">
                                    <input type="text" name="height" placeholder="height" class="form-control">
                                </div>
                            </div>
                        </div>       
                    </div>
                </div>
            </div>
       </div>
       </form>
    </div>
 


</div>

<?php
require('includes/footer.inc.php');
?>