<?php
require('includes/common.inc.php');

$def_seller_id = $_SESSION['default_id'];
$sql_ord = "SELECT DISTINCT orders.*,products_ordered.default_seller_id FROM orders,products_ordered WHERE products_ordered.default_seller_id = $def_seller_id AND products_ordered.order_id=orders.order_id ORDER BY order_id DESC";
$ord = mysqli_query($con,$sql_ord);

?>

<style>
  body{
    /*background-color: #87ceeb20;*/
    background-color: #aa207f30;
  }
  .card{
    /*border: 1px solid #87ceeb;*/
    border: 1px solid #aa207f00!important;
    box-shadow: 0 0 15px 0px #aaaaaa99;
  }

   h6.light-grey{
      color:#7a7a7a!important;
      font-size:12px;
      padding:0;
      margin:0;
   }
   h6.b-black{
      color:#000000!important;
      font-size:12px;
      padding:0;
      margin:0;
   }

   h6.small-black{
      
      font-size:13px;
      padding:0;
      margin-top:8px;
   }
   .noborder{
      border:none;
   }

</style>

<div class="container-fluid" style="padding: 100px 30px 30px 30px;">

  <div class="container-fluid">
    <div class="card mb-3">
      <div class="card-body">
        <h5 class="card-title">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb" style="background-color:rgba(0,0,0,0)!important;">
              <li class="breadcrumb-item active" aria-current="page"
                style="color: #000000; padding-top:10px; padding-left:10px; Font-size: 25px">Payments</li>
            </ol>
          </nav>
        </h5>
      </div>
    </div>
  </div>


  <div class="container-fluid">	
 	 <div class="content pb-0">
		<div class="orders">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div style="padding-left: 50px">
                                <table>
                                    <tr style="color:#aa207f;border-top:1px solid #aa207f;border-bottom:1px solid #aa207f">
                                      <td style="padding-top:10px;"><h6>Total Order Amount:</h6></td>
                                      <td style="padding-left:40px;padding-top:10px;"><h6>Rs. 10,000/-</h6></td>
                                    </tr>
                                    <tr>
                                      <td style="padding-top:20px"><h6>Shipping charges:</h6></td>
                                      <td style="padding-top:20px;padding-left:40px"><h6>Rs. 2,000/-</h6></td>
                                    </tr>
                                    <tr>
                                      <td><h6>Shipping GST:</h6></td>
                                      <td style="padding-left:40px"><h6>Rs. 360/-</h6></td>
                                    </tr>
                                    <tr>
                                      <td><h6>Other charges:</h6></td>
                                      <td style="padding-left:40px"><h6>Rs. 1,000/-</h6></td>
                                    </tr>
                                    <tr>
                                      <td style="padding-bottom:20px"><h6>Other GST:</h6></td>
                                      <td style="padding-left:40px;padding-bottom:20px"><h6>Rs. 180/-</h6></td>
                                    </tr>
                                    <tr style="color:green;border-top:2px solid green;border-bottom:2px solid green;">
                                      <td style="padding-top:10px"><h6>NET AMOUNT PAYABLE:</h6></td>
                                      <td style="padding-left:40px;padding-top:10px"><h6>Rs. 6,460/-</h6></td>
                                    </tr>
                                   
                                    
                                  </table>
                                
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>        
  </div>


</div>

<?php
require('includes/footer.inc.php');
?>