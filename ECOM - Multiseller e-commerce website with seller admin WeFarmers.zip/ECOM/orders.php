<?php
require('includes/common.inc.php');

$def_seller_id = $_SESSION['default_id'];
$sql_ord = "SELECT DISTINCT orders.*,products_ordered.default_seller_id FROM orders,products_ordered WHERE products_ordered.default_seller_id = $def_seller_id AND products_ordered.order_id=orders.order_id ORDER BY order_id DESC";
$ord = mysqli_query($con,$sql_ord);

?>

<style>
  body{
    /*background-color: #87ceeb20;*/
    background-color: #aa207f30;
  }
  .card{
    /*border: 1px solid #87ceeb;*/
    border: 1px solid #aa207f00!important;
    box-shadow: 0 0 15px 0px #aaaaaa99;
  }

   h6.light-grey{
      color:#7a7a7a!important;
      font-size:12px;
      padding:0;
      margin:0;
   }
   h6.b-black{
      color:#000000!important;
      font-size:12px;
      padding:0;
      margin:0;
   }

   h6.small-black{
      
      font-size:13px;
      padding:0;
      margin-top:8px;
   }
   .noborder{
      border:none;
   }

</style>

<div class="container-fluid" style="padding: 100px 30px 30px 30px;">

  <div class="container-fluid">
    <div class="card mb-3">
      <div class="card-body">
        <h5 class="card-title">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb" style="background-color:rgba(0,0,0,0)!important;">
              <li class="breadcrumb-item active" aria-current="page"
                style="color: #000000; padding-top:10px; padding-left:10px; Font-size: 25px">Orders</li>
            </ol>
          </nav>
        </h5>
      </div>
    </div>
  </div>


  <div class="container-fluid">	
 	 <div class="content pb-0">
		<div class="orders">
		<div class="row">
			<div class="col-xl-12">
				<div class="card">
					<div class="card-body">
                           <div class="table-stats order-table ov-h">
                              <table class="table">
                                 <thead>
                                    <tr style="font-size:12px">
                                       <th width=12%>Order Date</th>
                                       <th width=43%>Order Details</th>
                                       <th width=14%>Shipping</th>
                                       <th width=14%>Status</th>
                                       <th width=17%>Action</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php
                                    while($row_ord=mysqli_fetch_assoc($ord)){
                                       $total_qty=0;
                                    ?>
                                    <tr style="font-size:12px">
                                       <td><?php echo date("d M, Y",strtotime($row_ord['added_on'])); ?><br/><?php echo date(" h:i a",strtotime($row_ord['added_on'])); ?></td>
                                       <td>
                                          <h6 style="font-size:13px;color:#aa207f"><?php echo $row_ord['buyer_id']; ?>-<?php echo $row_ord['order_id']; ?>-<?php echo date("dmy",strtotime($row_ord['added_on'])); ?>-<?php echo date("his",strtotime($row_ord['added_on'])); ?></h6>
                                          <div class="row" style="padding-top:10px">
                                             <?php
                                                $order__id = $row_ord['order_id'];
                                                $sql_ord_prods = "SELECT * FROM products_ordered WHERE order_id=$order__id AND default_seller_id=$def_seller_id;";
                                                $ord_prods = mysqli_query($con,$sql_ord_prods);
                                                while($ordered_prods = mysqli_fetch_assoc($ord_prods)){
                                             ?>
                                             <div class="col-2">
                                                <img src="products_images/<?php echo $ordered_prods['image']; ?>" style="max-width:80px;max-height:80px"/>
                                             </div>
                                             <div class="col-10">
                                                <div style="padding-left:10px; padding-top:22px">
                                                   <h6 class="b-black" style="padding-bottom:5px"><?php echo $ordered_prods['product_name']; ?></h6>
                                                   <div class="row">
                                                      <div class="col-sm-3">
                                                         <h6 class="light-grey">QTY: <j style="color:#000"><?php echo $ordered_prods['product_quantity']; ?></j></h6>
                                                      </div>
                                                      <div class="col-sm-4">
                                                         <h6 class="light-grey">Product Id: <j style="color:#000"><?php echo $ordered_prods['product_id']; ?></j></h6>
                                                      </div>
                                                      <div class="col-sm-5">
                                                         <h6 class="light-grey">SKU: <j style="color:#000"></j></h6>
                                                      </div>
                                                      <?php 
                                                      $qntyy=$ordered_prods['product_quantity'];
                                                      $total_qty+=$qntyy;
                                                      ?>
                                                   </div>
                                                </div>
                                             </div>
                                             <?php } ?>
                                          </div>
                                          <div style="padding-top:25px">
                                             <h6 class="light-grey">Buyer Name: <j style="color:#000"><?php echo $row_ord['buyer_name']; ?></j></h6>
                                             <h6 class="light-grey"></h6>
                                             <h6 class="light-grey" style="padding-top:5px">Buyer Address:</h6>
                                             <h6 class="b-black"><?php echo $row_ord['buyer_address_line1']; ?></h6>
                                             <h6 class="b-black"><?php echo $row_ord['buyer_address_line2']; ?></h6>
                                             <h6 class="b-black"><?php echo $row_ord['buyer_state_ut']; ?></h6>
                                             <h6 class="b-black"><?php echo $row_ord['buyer_pincode']; ?></h6>
                                             <h6 class="light-grey" style="padding-top:5px">Phone no: <j style="color:#000"><?php echo $row_ord['buyer_mobile_number']; ?></j></h6>
                                          </div>
                                          </div>
                                       </td>
                                       <td>
                                          <h6 class="light-grey" style="padding-bottom:18px">Standard</h6>
                                          <h6 class="light-grey" style="padding-bottom:3px">Ship before:</h6>
                                          <h6 class="b-black" style="padding-bottom:18px">
                                             <?php
                                             $date1=date_create(date("d M, Y",strtotime($row_ord['added_on'])));
                                             date_add($date1,date_interval_create_from_date_string("3 days"));
                                             echo date_format($date1,"d M, Y");
                                             ?>
                                          </h6>
                                          <h6 class="light-grey" style="padding-bottom:3px">Deliver by:</h6>
                                          <h6 class="b-black" style="padding-bottom:3px">
                                          <?php
                                             $date2=date_create(date("d M, Y",strtotime($row_ord['added_on'])));
                                             date_add($date2,date_interval_create_from_date_string("7 days"));
                                             echo date_format($date2,"d M, Y");
                                             ?> to
                                          </h6>
                                          <h6 class="b-black" style="padding-bottom:3px">
                                          <?php
                                             $date3=date_create(date("d M, Y",strtotime($row_ord['added_on'])));
                                             date_add($date3,date_interval_create_from_date_string("10 days"));
                                             echo date_format($date3,"d M, Y");
                                             ?>
                                          </h6>
                                       </td>
                                       <td>
                                          <h6 style="color:red;font-size:14px;padding-top:60px">Unshipped (<?php echo $total_qty ?>)</h6>
                                       </td>
                                       <td>
                                       <button id="payment-button" name="invoice" type="submit" class="btn btn-block btn-default8">
                                          <span id="payment-button-amount">Generate Invoice</span>
                                       </button>
                                       <button id="payment-button" name="process_order" type="submit" class="btn btn-block btn-default9">
                                          <span id="payment-button-amount">Process Order</span>
                                       </button>
                                       <button id="payment-button" name="self_ship" type="submit" class="btn btn-block btn-default8">
                                          <span id="payment-button-amount">Self Ship</span>
                                       </button>
                                       <button id="payment-button" name="order_slips" type="submit" class="btn btn-block btn-default9">
                                          <span id="payment-button-amount">Print Order Slips</span>
                                       </button>
                                       </td>
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
		  </div>
      </div>   

</div>

<?php
require('includes/footer.inc.php');
?>