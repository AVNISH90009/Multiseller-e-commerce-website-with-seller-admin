-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2021 at 10:53 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `farmers_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `buyer_details`
--

CREATE TABLE `buyer_details` (
  `buyer_id` int(11) NOT NULL,
  `buyer_name` varchar(255) NOT NULL,
  `buyer_email` varchar(255) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `buyer_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buyer_details`
--

INSERT INTO `buyer_details` (`buyer_id`, `buyer_name`, `buyer_email`, `added_on`, `buyer_password`) VALUES
(1, 'Avnish K', 'avnishkatiyar9@gmail.com', '2021-06-20 08:59:41', '1234'),
(2, 'nnnnnnnn', 'nnn@nnn.com', '2021-06-20 05:32:41', 'nn'),
(3, 'Narayan', 'narayan@narayan.com', '2021-06-24 06:15:21', 'Narayan@123'),
(4, 'suman', 'suman90009k@gmail.com', '2021-06-30 22:11:20', 'farmers123'),
(5, 'kuldip singh', 'kuldip60singh@gmail.com', '2021-07-01 01:11:43', 'kuld1234'),
(6, 'Avnish Katiyar', 'avnishk@gmail.com', '2021-07-01 22:00:27', 'hp1234'),
(7, 'S Narayan', 'snarayan@narayan.com', '2021-07-14 04:39:08', 'sn123'),
(8, 'Avnish Kumar', 'avnish@gmail.com', '2021-07-13 21:41:32', 'Avi@12345');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `categories` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categories`, `status`) VALUES
(1, 'Fruits', 1),
(2, 'Grains', 1),
(3, 'Vegetables', 1),
(4, 'Other Consumables', 1),
(5, 'Pulses', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `comment` text NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`id`, `name`, `email`, `phone_no`, `comment`, `time`) VALUES
(1, 'Avnish', 'avnishkatiyar9@gmail.com', '9251234567', 'Lorem ipsum', '2020-12-23 11:39:37');

-- --------------------------------------------------------

--
-- Table structure for table `new_user`
--

CREATE TABLE `new_user` (
  `default_id` int(11) NOT NULL,
  `user_id` varchar(15) NOT NULL,
  `name` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `mobile_number` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `cpassword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `new_user`
--

INSERT INTO `new_user` (`default_id`, `user_id`, `name`, `gender`, `dob`, `mobile_number`, `password`, `cpassword`) VALUES
(1, 'Admin123', 'Admin kumar', 'Male', '3453-04-05', '9815465652', 'Admin@123', 'Admin@123'),
(2, 'Avnish123', 'Avnish Katiyar', 'Male', '1992-03-18', '9816532156', 'Avnish123', 'Avnish123'),
(3, 'Avi12345', 'Avnish K', 'Male', '2005-02-01', '8700715099', 'Avi@12345', 'Avi@12345'),
(4, 'jaspreet29', 'Jaspreet singh', 'Male', '1999-01-29', '7503098752', 'Ja123456789', 'Ja123456789'),
(5, 'Avnish123', 'Avnish', 'Male', '1990-06-27', '8700715264', 'Avnish@123', 'Avnish@123'),
(6, 'Wonder123', 'Wonderful Singh', 'Male', '1980-12-22', '8282123456', 'Wonder@123', 'Wonder@123'),
(7, 'Wonder1234', 'Wonder Kaur', 'Female', '1994-09-22', '8284123456', 'Wonder@1234', 'Wonder@1234'),
(8, 'mrdummy123', 'Mr Dummy', 'Male', '2002-02-22', '8700123456', 'Mrdummy@123', 'Mrdummy@123'),
(9, 'kuldip1234', 'kuldip singh', 'Male', '1961-08-15', '8284009933', 'Kuld1961', 'Kuld1961'),
(10, 'NarayanShri123', 'Shri Narayan', 'Male', '0001-01-01', '8700710000', 'Sh.N1234', 'Sh.N1234');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `buyer_name` varchar(50) NOT NULL,
  `buyer_mobile_number` varchar(10) NOT NULL,
  `buyer_address_line1` varchar(250) NOT NULL,
  `buyer_address_line2` varchar(250) NOT NULL,
  `buyer_state_ut` varchar(50) NOT NULL,
  `buyer_pincode` int(6) NOT NULL,
  `buyer_add_info` varchar(250) NOT NULL,
  `payment_type` varchar(30) NOT NULL,
  `payment_status` varchar(30) NOT NULL,
  `order_status` varchar(30) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `buyer_id`, `buyer_name`, `buyer_mobile_number`, `buyer_address_line1`, `buyer_address_line2`, `buyer_state_ut`, `buyer_pincode`, `buyer_add_info`, `payment_type`, `payment_status`, `order_status`, `added_on`, `total_price`) VALUES
(7, 3, 'Narayan', '2147483647', 'xyz, 123, street 420, Delhi', 'Shalimar Bagh, New DElhi', 'Delhi', 110056, 'Perfect', 'COD', 'Success', 'Pending', '2021-06-25 04:42:53', 620),
(8, 3, 'Narayan', '0870071526', 'xyz, 123, street 420, Delhi', 'ND', 'Delhi', 110056, '                                    DD', 'COD', 'Success', 'Pending', '2021-06-26 06:59:20', 620),
(9, 4, 'suman', '9891326812', '1445, 2nd floor, Gali No.7', 'Wazir Nagar, Kotla Mubarakpur, Delhi', 'Delhi', 110003, 'Weekend delivery only.                                    ', 'COD', 'Success', 'Pending', '2021-06-30 22:19:44', 2520),
(10, 5, 'kuldip singh', '8284009933', '1445/7 street no. 7, wazir nagar, Kotla Mubarakpur, Delhi 110003', 'south delhi', 'Delhi', 110003, '       Opp Yes Bank Defence Colony Branch                           ', 'COD', 'Success', 'Pending', '2021-07-01 01:22:26', 540),
(11, 6, 'Avnish Katiyar', '7053123456', 'Building No. 14, xyz street', 'Delhi Cantt., New Delhi', 'Delhi', 110049, 'Please deliver in weekends only', 'COD', 'Success', 'Pending', '2021-07-01 22:16:53', 360),
(12, 7, 'S Narayan', '8700711234', 'abc Building', '123 stoymarg Road', 'Gujrat', 123456, 'Best time available', 'COD', 'Success', 'Pending', '2021-07-14 04:42:56', 1590),
(13, 8, 'Avnish Kumar', '7053123456', 'xyz, 123, street 420', 'Delhi Cantt', 'Delhi', 110056, 'Need to deliver only in evening', 'COD', 'Success', 'Pending', '2021-07-13 21:44:56', 2670),
(14, 3, 'Narayan', '8700123456', 'abc, x street ,bla', 'Delhi Cantt.', 'Delhi', 100555, '                                    ', 'COD', 'Success', 'Pending', '2021-07-14 01:44:07', 6300);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `default_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  `sku` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `mrp` float NOT NULL,
  `selling_price` float NOT NULL,
  `qty` int(11) NOT NULL,
  `qty_unit` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `short_desc` varchar(2000) NOT NULL,
  `description` text NOT NULL,
  `meta_title` text NOT NULL,
  `meta_desc` varchar(2000) NOT NULL,
  `meta_keyword` varchar(2000) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `weight` float DEFAULT NULL,
  `length` float DEFAULT NULL,
  `width` float DEFAULT NULL,
  `height` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`default_id`, `id`, `categories_id`, `sku`, `title`, `mrp`, `selling_price`, `qty`, `qty_unit`, `image`, `short_desc`, `description`, `meta_title`, `meta_desc`, `meta_keyword`, `status`, `weight`, `length`, `width`, `height`) VALUES
(5, 44, 2, 'AL250DF001', 'Rich Almond 250g pack mini', 500, 300, 210, 'Nos', '5_25439536_staples.jpg', 'khfs', 'khfewk', '', '', '', 0, 0, 0, 0, 0),
(5, 46, 3, 'LD500001', 'Fresh Lady finger 50kg Bag', 500, 300, 210, 'Nos', '5_84772814_staples.jpg', 'hfkd', 'kjjvkh', '', '', '', 0, 50, 5, 5, 5),
(5, 47, 1, 'AP54000001', 'Apple 1 kg', 500, 300, 0, 'Bags', '5_18877574_of11.png', 'hkjhkjfdhkj kjhvkjfbh kjhkfhkf', ',sndkjhskj', '', '', '', 0, 1, 20, 10, 8),
(6, 48, 3, 'LD10001A', 'Ladyfinger 1kg', 40, 20, 20, 'Nos', '6_75660852_of17.png', 'HFVJ KFKBVDF KHVKJKFH', 'kjdjhvfkj jkhfvjkfh kjkjvhjkdf kjbjvfb', '', '', '', 1, 1, 5, 5, 5),
(6, 49, 1, 'GR001001', 'Grapes 1 kg', 100, 80, 20, 'Nos', '6_18727685_of19.png', 'mvmbh kghkjd ksfhk khsd', 'hkhvkj hdfvkjh vkjdkj bkvjdfbk', '', '', '', 1, 1, 20, 20, 20),
(6, 50, 1, 'BN150001', 'Banana 1.5 Dozen', 85, 60, 30, 'Nos', '6_43531430_of26.png', 'hfuieh kjhfkerh hoferhh', 'kjhgkjhe', '', '', '', 0, 2, 15, 15, 15),
(6, 51, 3, 'BG0010001', 'Bitter Guard 1 kg', 45, 20, 20, 'Nos', '6_46932543_of10.png', 'bdfb kjnkjbnkjsfd kjnkenfjnsfjk hbvhbsjh', ',nfvnn jnvjsenv ,n sdnj jnbj', '', '', '', 1, 1, 10, 20, 30),
(5, 52, 4, 'sg001', 'sugar 1kg', 50, 40, 100, 'Nos', '5_54179085_ph0ag026-1-593375_l.jpg', 'sugar 1 kg', 'made from up mills', '', '', '', 1, 1, 15, 15, 5),
(5, 58, 1, 'AKWL2500001', 'Archs Kagzr Walnut 250g', 500, 300, 42, 'Nos', '5_86660672_akhrot.png', 'Lorem Ipsum', 'Lorem Ipsum', '', '', '', 1, 250, 10, 10, 8),
(5, 59, 1, 'AL2500001', 'Archs Shuddh Almonds 250g', 500, 450, 20, 'Nos', '5_31937181_full-frame-shot-of-raw-almonds-royalty-free-image-683814187-1537885519.jpg', 'Lorem Ipsum', 'Lorem Ipsum', '', '', '', 0, 250, 10, 10, 8),
(8, 60, 3, 'LEMON50001', 'Fresh Lemon 5kg', 600, 450, 2, 'Nos', '8_97660282_fc60eb5f-d6b1-4718-a4b1-9118a968af8a.jpg', 'Lorem Ipsum', 'Lorem Ipsum', '', '', '', 1, 5, 15, 15, 10),
(5, 61, 5, 'CHANADAL01', 'Chana Dal 1kg', 150, 90, 50, 'Bags', '5_36069722_loose-chana-dal-1-kg-0-20210302.jpg', 'High quality ORGANIC Chana Pulses.', 'This product is prepared from recent organic technology. ...', '', '', '', 1, 1, 10, 10, 10),
(9, 62, 1, 'coco1234', 'coconut dry 5 kg', 800, 400, 50, 'Bags', '9_16087363_coconut-koparai.jpg', 'coconuts are brought fresh from kerala ', 'Enrich in oil content & very tasty.', '', '', '', 1, 5.1, 30, 20, 10),
(10, 63, 3, 'CAPC0001', 'Green Capsicum 500g', 50, 30, 80, 'Bags', '10_50199472_green-capsicum-500-g-0-20201118.jpg', 'Fresh and Green Capsicum', 'Fresh and Green Capsicum straight from our farmlands only for you and at best reasonable price, superior quality, strong packing to avoid transit damages. Best vegetable for your health..', '', '', '', 1, 500, 15, 15, 10),
(10, 64, 5, 'MOONGS0001', 'Sabut Moong Dal 1kg pack', 120, 90, 50, 'Bags', '10_12360792_sabut-moong-dal-500x500.jpg', 'Sabut Moong Dal 1 kg at best price', 'Sabut Moong Dal 1 kg straight from farmlands to your home supplied from experienced Narayan farmer. Fresh and free from dirt.', '', '', '', 1, 1, 12, 12, 8),
(5, 65, 2, 'BAS00001', 'Basmati Rice 25kg', 1200, 900, 100, 'Bags', '5_41731384_20210409_172056_0000-300x300.jpg', 'Best Quality Basmati Rice', 'Presenting the best quality Basmati Rice straight from my farmlands to your Kitchen with Best Quality, Best Price..', '', '', '', 1, 25, 20, 10, 40);

-- --------------------------------------------------------

--
-- Table structure for table `products_ordered`
--

CREATE TABLE `products_ordered` (
  `product_order_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `default_seller_id` int(11) NOT NULL,
  `mrp` int(11) NOT NULL,
  `selling_price` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `image` varchar(250) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `subtotal_price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products_ordered`
--

INSERT INTO `products_ordered` (`product_order_id`, `order_id`, `product_id`, `default_seller_id`, `mrp`, `selling_price`, `product_name`, `image`, `product_quantity`, `subtotal_price`) VALUES
(16, 7, 49, 6, 100, 80, 'Grapes 1 kg', '6_18727685_of19.png', 4, 240),
(17, 7, 51, 6, 45, 20, 'Bitter Guard 1 kg', '6_46932543_of10.png', 9, 60),
(18, 7, 52, 5, 50, 40, 'sugar 1kg', '5_54179085_ph0ag026-1-593375_l.jpg', 3, 120),
(19, 8, 49, 6, 100, 80, 'Grapes 1 kg', '6_18727685_of19.png', 4, 320),
(20, 8, 51, 6, 45, 20, 'Bitter Guard 1 kg', '6_46932543_of10.png', 9, 180),
(21, 8, 52, 5, 50, 40, 'sugar 1kg', '5_54179085_ph0ag026-1-593375_l.jpg', 3, 120),
(22, 9, 49, 6, 100, 80, 'Grapes 1 kg', '6_18727685_of19.png', 10, 800),
(23, 9, 50, 6, 85, 60, 'Banana 1.5 Dozen', '6_43531430_of26.png', 5, 300),
(24, 9, 52, 5, 50, 40, 'sugar 1kg', '5_54179085_ph0ag026-1-593375_l.jpg', 1, 40),
(25, 9, 51, 6, 45, 20, 'Bitter Guard 1 kg', '6_46932543_of10.png', 9, 180),
(26, 9, 58, 5, 500, 300, 'Archs Kagzr Walnut 250g', '5_86660672_akhrot.png', 4, 1200),
(27, 10, 48, 6, 40, 20, 'Ladyfinger 1kg', '6_75660852_of17.png', 2, 40),
(28, 10, 50, 6, 85, 60, 'Banana 1.5 Dozen', '6_43531430_of26.png', 1, 60),
(29, 10, 52, 5, 50, 40, 'sugar 1kg', '5_54179085_ph0ag026-1-593375_l.jpg', 1, 40),
(30, 10, 62, 9, 800, 400, 'coconut dry 5 kg', '9_16087363_coconut-koparai.jpg', 1, 400),
(31, 11, 50, 6, 85, 60, 'Banana 1.5 Dozen', '6_43531430_of26.png', 1, 60),
(32, 11, 58, 5, 500, 300, 'Archs Kagzr Walnut 250g', '5_86660672_akhrot.png', 1, 300),
(33, 12, 50, 6, 85, 60, 'Banana 1.5 Dozen', '6_43531430_of26.png', 1, 60),
(34, 12, 63, 10, 50, 30, 'Green Capsicum 500g', '10_50199472_green-capsicum-500-g-0-20201118.jpg', 6, 180),
(35, 12, 60, 8, 600, 450, 'Fresh Lemon 5kg', '8_97660282_fc60eb5f-d6b1-4718-a4b1-9118a968af8a.jpg', 3, 1350),
(36, 13, 63, 10, 50, 30, 'Green Capsicum 500g', '10_50199472_green-capsicum-500-g-0-20201118.jpg', 4, 120),
(37, 13, 58, 5, 500, 300, 'Archs Kagzr Walnut 250g', '5_86660672_akhrot.png', 7, 2100),
(38, 13, 64, 10, 120, 90, 'Sabut Moong Dal 1kg pack', '10_12360792_sabut-moong-dal-500x500.jpg', 5, 450),
(39, 14, 60, 8, 600, 450, 'Fresh Lemon 5kg', '8_97660282_fc60eb5f-d6b1-4718-a4b1-9118a968af8a.jpg', 3, 1350),
(40, 14, 65, 5, 1200, 900, 'Basmati Rice 25kg', '5_41731384_20210409_172056_0000-300x300.jpg', 5, 4500),
(41, 14, 61, 5, 150, 90, 'Chana Dal 1kg', '5_36069722_loose-chana-dal-1-kg-0-20210302.jpg', 5, 450);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buyer_details`
--
ALTER TABLE `buyer_details`
  ADD PRIMARY KEY (`buyer_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_user`
--
ALTER TABLE `new_user`
  ADD PRIMARY KEY (`default_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_ordered`
--
ALTER TABLE `products_ordered`
  ADD PRIMARY KEY (`product_order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `buyer_details`
--
ALTER TABLE `buyer_details`
  MODIFY `buyer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `new_user`
--
ALTER TABLE `new_user`
  MODIFY `default_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `products_ordered`
--
ALTER TABLE `products_ordered`
  MODIFY `product_order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
