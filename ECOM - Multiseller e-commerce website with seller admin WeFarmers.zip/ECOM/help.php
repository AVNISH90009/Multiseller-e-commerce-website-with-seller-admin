<?php
require('includes/common.inc.php');
?>

<div style="padding:30px 30px 100px 30px">

    <div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page" style="color:green; padding-top:10px; padding-left:10px; Font-size: 25px">Help</li>
            </ol>
        </nav>
        </h5>
    </div>
    </div>

</div>

<?php
require('includes/footer.inc.php');
?>