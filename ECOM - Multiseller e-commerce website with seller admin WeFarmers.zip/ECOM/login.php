<!doctype html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php require('includes/bootstrap_link.inc.php'); ?> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/login.css"> 
  <title>Login form</title>
</head>

<body>
  <header>
    <nav class="navbar fixed-top" style="background-color: #aa207f; padding:0px;">
      <div class="container">
        <div>
          <a class="navbar-brand" href="index.php" style="color: White;">
            <h1 class="header-logo"><strong>WeFarmers</strong></h1>
            <h1 class="header-logo">Seller Central</h1>
          </a>
        </div>
        <div>
          <a href="farmer_registration.php" class="btn btn-default1">Sign Up</a>
        </div>
      </div>
    </nav>
  </header>
  
  <div class="container-fluid main">
    <div class="row">
      <div class="col">
      <img src="images/greenleaves.png" class="img-fluid" alt="green leaves" id="reg_leaves">
      </div>
      <div class="col">
        <div class="col-md-8 border rounded form" style="border: 2px solid #aa207f!important;">
          <p class="text-center h4 font-weight-bolder mb-3 mt-3">Login to WE FARMERS</p>
          <form action="login_check.php" method="POST">
            <div class="form-group">
              <input type="text" title="Enter Username" class="form-control" id="user_id" name="user_id"
                placeholder="Username" required>
            </div>
            <div class="form-group">
              <input type="password" title="Enter Password" class="form-control" id="password" name="password"
                placeholder="Password" required>
            </div>
            <div class="row">
              <div class="col-sm">
                <div class="form-group">
                  <div class="d-grid gap-2">
                    <button class="btn btn-block btn-default4" style="margin-left:0; margin-top: 20px;" type="submit" name="submit">Login</button>
                  </div>
                </div>
              </div>
            </div>
            <!-- <a class="color" href="#">Forget Password?</a> -->
          </form>
          <div class = "error_text_message"></div>
        </div>
        <div class="col-md-4"></div>
      </div>
    </div>
  </div>

  <div class="card" >
    <div class="card-body">
      <div class="container">
        <div class="row" style="align: right!important; padding-top: 20px">
              <div class="col-sm-5"></div>
              <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Terms of Services</p></div>
              <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Privacy Policy</p></div>
              <div class="col-sm-3"><p style="font-size: 12px; color: #7a7a7a">Copyright 2021, WeFarmers</p></div>
        </div>
      </div>
    </div>
  </div>

  <?php require('includes/bootstrap_js.inc.php'); ?>

</body>

</html>