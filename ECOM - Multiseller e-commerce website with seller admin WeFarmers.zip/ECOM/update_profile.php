<?php
require('includes/common.inc.php');
?>

<div style="padding:30px 30px 100px 30px">

    <div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item active" aria-current="page" style="color:green; padding-top:10px; padding-left:10px; Font-size: 25px">Update Profile</li>
            </ol>
        </nav>
        </h5>
    </div>
    </div>
    <form action="insert_form3.php" method="POST">
                
                
                
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Please enter Father's Name as per Aadhar" id="father_name" name="father_name" aria-label="Father_Fullname" aria-describedby="basic-addon1" placeholder="Please enter Full Name as per Aadhar" title="Name should contain Alphabets only" pattern="^[A-Za-z -]+$" required>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Please enter Mother's Name as per Aadhar" id="mother_name" name="mother_name" aria-label="Mother_Fullname" aria-describedby="basic-addon1" placeholder="Please enter Full Name as per Aadhar" title="Name should contain Alphabets only" pattern="^[A-Za-z -]+$" required>
                </div>

             <div class="form-group">
              <select id="marital_status" name="marital_status" class="form-control" title="Please select your Marital Status" required>
                 <option value="">Choose Marital Status.. </option>
                 <option>Unmarried</option>
                 <option>Married</option>
                 <option>Divorcee</option>
                 </select>
             </div>
             
             <div class="form-group">
              <input type="text" class="form-control" id="present_address1" name="present_address1" placeholder="Present Address Line 1: House no., street, Mohalla" title="Enter your Address" required>
             </div>
            
             <div class="form-group">
              <input type="text" class="form-control" id="present_address2" name="present_address2" placeholder="Present Address Line 2: Landmark Details" title="Enter your Address" required>
             </div>
            <div class="form-row">

            
            <div class="form-group col-md-6">
              <select id="present_tehsil" name="present_tehsil" class="form-control" title="Please select your Tehsil" required>
                <option value="">Tehsil..</option>
                <option>Mori</option>
                <option>Purola</option>
                <option>Rajgarhi</option>
                <option>Uttarkasi</option>
              </select>
            </div>
            
            <div class="form-group col-md-6">
              <select id="present_city" name="present_city" class="form-control" title="Please select your City" required>
                <option value="">City..</option>
                <option>Dehradun</option>
                <option>Haridwar</option>
                <option>Roorkee</option>
                <option>Rishikesh</option>
                <option>Rudrapur</option>
                <option>...</option>
              </select>
            </div>
          </div>
            <div class="form-row">
              <div class="form-group col-md-6">
                <select id="present_district" name="present_district" class="form-control" title="Please select your District" required>
                  <option value="">District..</option>
                  <option>Dehradun</option>
                  <option>Haridwar</option>
                  <option>Nainital</option>
                  <option>Udham Singh Nagar</option>
                  <option>...</option>
                </select>
              </div>
              <div class="form-group col-md-6">
                <input type="text" class="form-control" id="present_pincode" name="present_pincode" placeholder="Pincode" title="Please enter your Pincode" pattern="[0-9]{6}" required>
              </div>
             
            </div>
            <div class="form-row">
              <div class="form-group col-md-12">
                <select id="present_state" name="present_state" class="form-control" title="Please select your State" required>
                  <option value=""> State..</option>
                  <option>NCT  Delhi</option>
                  <option>Uttar Pradesh</option>
                  <option>Uttarakhand</option>
                  <option>...</option>
                </select>
              </div>
            </div>
          <div class="form-group form-check">
            
              <input type="checkbox" onclick="sameAddress()" class="form-check-input size-check mb-3" id="check" name="check" title="Please check if Permanent address is same as above">
              <label class="form-check-label font-weight-bolder size-check-label mb-3 pt-2 pl-3" for="check"> Click if your Permanent Address same as Present Address</label>
              <script>
                function sameAddress()
                {
                  var checkbox = document.getElementById('check');
                  if (checkbox.checked = true)
                  {
                    var x1 = document.getElementById('present_address1').value;
                    document.getElementById('permanent_address1').value = x1;
                    var x2 = document.getElementById('present_address2').value;
                    document.getElementById('permanent_address2').value = x2;
                    var x3 = document.getElementById('present_tehsil').value;
                    document.getElementById('permanent_tehsil').value = x3;
                    var x4 = document.getElementById('present_city').value;
                    document.getElementById('permanent_city').value = x4;
                    var x5 = document.getElementById('present_district').value;
                    document.getElementById('permanent_district').value = x5;
                    var x6 = document.getElementById('present_state').value;
                    document.getElementById('permanent_state').value = x6;
                    var x7 = document.getElementById('present_pincode').value;
                    document.getElementById('permanent_pincode').value = x7;
                  }
                }
              </script>
          </div>

          <script>
            
           
          </script>
             
            <div class="form-group">
              <input type="text" class="form-control" id="permanent_address1" name="permanent_address1" placeholder="Permanent Address Line 1: House no., street, Mohalla" title="Enter your Address" required>
             </div>

             <div class="form-group">
              <input type="text" class="form-control" id="permanent_address2" name="permanent_address2" placeholder="Present Address Line 2: Landmark Details" title="Enter your Address" required>
             </div>

            <div class="form-row">

            
              <div class="form-group col-md-6">
                <select id="permanent_tehsil" name="permanent_tehsil" class="form-control" title="Please select your Tehsil" required>
                  <option value="">Tehsil..</option>
                  <option>Mori</option>
                  <option>Purola</option>
                  <option>Rajgarhi</option>
                  <option>Uttarkasi</option>
                </select>
              </div>
              
              <div class="form-group col-md-6">
                <select id="permanent_city" name="permanent_city" class="form-control" title="Please select your City" required>
                  <option value="">City..</option>
                  <option>Dehradun</option>
                  <option>Haridwar</option>
                  <option>Roorkee</option>
                  <option>Rishikesh</option>
                  <option>Rudrapur</option>
                  <option>...</option>
                </select>
              </div>
            </div>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <select id="permanent_district" name="permanent_district" class="form-control" title="Please select your District" required>
                    <option value="">District..</option>
                    <option>Dehradun</option>
                    <option>Haridwar</option>
                    <option>Nainital</option>
                    <option>Udham Singh Nagar</option>
                    <option>...</option>
                  </select>
                </div>
                <div class="form-group col-md-6">
                  <input type="text" class="form-control" id="permanent_pincode" name="permanent_pincode" placeholder="Pincode" title="Please enter your Pincode" pattern="[0-9]{6}" required>
                </div>
               
              </div>
              <div class="form-row">
                <div class="form-group col-md-12">
                  <select id="permanent_state" name="permanent_state" class="form-control" title="Please select your State" required>
                    <option value=""> State..</option>
                    <option>NCT  Delhi</option>
                    <option>Uttar Pradesh</option>
                    <option>Uttarakhand</option>
                    <option>...</option>
                  </select>
                </div>
              </div>
         
              <div class="form-group">
                <input type="mail" class="form-control" id="email" name="email" placeholder="Email Address" required>
              </div>
      
              <button type="submit" class="btn btn-primary mb-2">Save & Update</button>
               
              </form>
         </div>
         <div class="col-md-3"></div>
     </div>
 </div>

</body>

</div>

<?php
require('includes/footer.inc.php');
?>