<?php

require('includes/connection.inc.php');

if(!mysqli_select_db($con,'farmers_ecommerce')){
	echo "Database not selected.";
}

if(isset ($_POST['submit'])){
    $user_id = $_POST['user_id'];
    $password = $_POST['password'];

    $sql_login = "SELECT * FROM new_user WHERE user_id = '$user_id' AND password = '$password';";

    $query = mysqli_query($con,$sql_login);

    $row = mysqli_num_rows($query);

    if ($row == 1){
        echo "Login Successful";

        while($arr_row = $query->fetch_assoc())
        {
            $_SESSION['default_id'] = $arr_row['default_id'];
            $_SESSION['user_id'] = $arr_row['user_id'];
            $_SESSION['name'] = $arr_row['name'];
            $_SESSION['gender'] = $arr_row['gender'];
            $_SESSION['dob'] = $arr_row['dob'];
            $_SESSION['mobile_number'] = $arr_row['mobile_number'];
            header('location: dashboard.php');
        }
    }

    else{
        echo "Please enter valid login credentials";
    }
}

?>