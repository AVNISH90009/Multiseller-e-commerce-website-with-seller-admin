<?php
session_start();
$_SESSION['cart']='';
unset($_SESSION['cart']);
require('includes/common.inc.php')
?>

<div class="container-fluid" style="margin:120px 0 20px 0;">
    <div class="card">
        <div class="card-body" style="padding:0">
            <div class="card-title">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-2" style="background-color:#ffffff;margin-left:30px;font-size:20px">
                        <li class="breadcrumb-item"><a href="index.php"><strong>Home</strong></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><strong>Thankyou</strong></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <div class="container">
                <div class="card" style="border:none">
                    <div class="card-body">
                        <h4 style="color:green">Thankyou, your order has been placed successfully.</h4>
                        <a href="your_orders.php"><h6 style="view orders">View your orders</h6></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require('includes/footer.inc.php')
?>