<?php

require('includes/connection.inc.php');

if(!mysqli_select_db($con,'farmers_ecommerce')){
	echo "Database not selected.";
}

if(isset($_POST['submit'])){
    $buyer_email = $_POST['buyer_email'];
    $buyer_password = $_POST['buyer_password'];

    $sql_buyer_login = "SELECT * FROM buyer_details WHERE buyer_email='$buyer_email' AND buyer_password='$buyer_password';";
    $query = mysqli_query($con,$sql_buyer_login);
    $row_count = mysqli_num_rows($query);

    if($row_count==1){
        echo "Login Successful";

        while($row = mysqli_fetch_assoc($query)){
            $_SESSION['BUYER_ID'] = $row['buyer_id'];
            $_SESSION['BUYER_NAME'] = $row['buyer_name'];
            $_SESSION['BUYER_EMAIL'] = $row['buyer_email'];
            header ("refresh:1; url=index.php"); 
        } 
    }else{
        echo "Please enter valid login credentials..";
        header ("refresh:1; url=login.php");
    }
}

?>