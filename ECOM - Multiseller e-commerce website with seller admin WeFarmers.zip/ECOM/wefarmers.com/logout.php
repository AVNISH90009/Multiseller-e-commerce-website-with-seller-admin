<?php
session_start();
$_SESSION['BUYER_ID']='';
$_SESSION['BUYER_NAME']='';
$_SESSION['BUYER_EMAIL']='';
unset($_SESSION['BUYER_ID']);
unset($_SESSION['BUYER_NAME']);
unset($_SESSION['BUYER_EMAIL']);
header('location: index.php');
die();
?>