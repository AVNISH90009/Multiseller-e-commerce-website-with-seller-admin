<?php
require('includes/connection.inc.php');
require('includes/functions.inc.php');
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php require('includes/bootstrap_link.inc.php'); ?>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/common.inc.css">
  <title></title>
</head>
<body>

  <nav class="navbar fixed-top navbar-toggleable-sm navbar-inverse bg-inverse">
    <a class="navbar-brand mx-auto" href="index.php" style="color:#77003a;font-size:30px"><h1 style="font-size:35px">WeFarmers</h1></a>
  </nav>

  <div class="row" style="margin-top:60px">
    <div class="col-sm-4">
      <div class="card" style="border:none; background-color: #aa207f00">
        <div class="card-body">

        </div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="card">
        <div class="card-body">
          <h3> Create Account </h3>
          <form action="insert_buyer_reg.php" method="post">

            <div class="form-group">
              <label for="username">Name</label>
              <input type="text" class="form-control" name="buyer_name" id="buyer_name"
              placeholder="Enter your name" title="Name should contain Alphabets only" 
              pattern="^[A-Za-z -]+$" required>
            </div>
            
            <div class="form-group">
              <label for="email">Email address</label>
              <input type="email" class="form-control" name="buyer_email" id="buyer_email" aria-describedby="emailHelp"
                placeholder="Enter email" title="Enter vali email address" required>
              <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>

            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" name="buyer_password" id="buyer_password" placeholder="Password" 
              title="Password must contain minimum 8 characters, including minimum one Alphabet 
                      (one uppercase and one lowercase), one Numeric and one Special Character." required>
            </div>

            <div class="form-group">
              <label for="password">Confirm Password</label>
              <input type="password" class="form-control" name="cpassword" id="cpassword" placeholder="Password" required>
            </div>

            <button type="submit" class="btn btn-default5 btn-block" style="padding:5px!important">Submit</button>
          </form>
          <hr/>
          <p><small> Already have an account? <a href="login.php">Login here</a></small></p>
        </div>
      </div>
    </div>
    <div class="col-sm-4">    
      <div class="card"  style="border:none;background-color: #aa207f00">
        <div class="card-body">
        </div>
      </div>
    </div>
  </div>
  

  <?php require('includes/bootstrap_js.inc.php'); ?>
</body>

</html>