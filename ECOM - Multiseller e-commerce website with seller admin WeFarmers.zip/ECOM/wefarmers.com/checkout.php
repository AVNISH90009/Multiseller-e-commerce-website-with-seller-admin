<?php
require('includes/common.inc.php');

$p_total_price=0;
foreach($_SESSION['cart'] as $key=>$value){
    $productArr=get_product_sp($con,'','','',$key);
    $p_price=$productArr['0']['selling_price'];
    $p_quantity=$value['q'];
    $p_subtotal=(int)$p_quantity*(int)$p_price;
    $p_total_price+=$p_subtotal;
}

if(isset($_POST['place_order'])){
    $buyer_id = $_SESSION['BUYER_ID'];
    $buyer_name = $_POST['buyer_name'];
    $buyer_mobile_number = $_POST['buyer_mobile_number'];
    $buyer_address_line1 = $_POST['buyer_address_line1'];
    $buyer_address_line2 = $_POST['buyer_address_line2'];
    $buyer_state_ut = $_POST['buyer_state_ut'];
    $buyer_pincode = $_POST['buyer_pincode'];
    $buyer_add_info = $_POST['buyer_add_info'];
    $payment_type = 'COD';
    if($payment_type == 'COD'){
        $payment_status = 'Success';
    }
    $order_status = 'Pending';
    $added_on = date('Y-m-d h:i:s');
    $total_price = $p_total_price;

    #echo "INSERT INTO orders (buyer_name,buyer_mobile_number,buyer_address_line1,buyer_address_line2,buyer_state_ut,buyer_pincode,buyer_add_info,payment_type,payment_status,order_status,added_on,total_price) VALUES ('$buyer_id','$buyer_name','$buyer_mobile_number','$buyer_address_line1','$buyer_address_line2','$buyer_state_ut','$buyer_pincode','$buyer_add_info','$payment_type','$payment_status','$order_status','$added_on','$total_price');";
    mysqli_query($con,"INSERT INTO orders (buyer_id,buyer_name,buyer_mobile_number,buyer_address_line1,buyer_address_line2,buyer_state_ut,buyer_pincode,buyer_add_info,payment_type,payment_status,order_status,added_on,total_price) VALUES ('$buyer_id','$buyer_name','$buyer_mobile_number','$buyer_address_line1','$buyer_address_line2','$buyer_state_ut','$buyer_pincode','$buyer_add_info','$payment_type','$payment_status','$order_status','$added_on','$total_price');");

    $order_id = mysqli_insert_id($con);

    foreach($_SESSION['cart'] as $key=>$value){
        $productArr=get_product_sp($con,'','','',$key);
        $selling_price=$productArr['0']['selling_price'];
        $default_seller_id=$productArr['0']['default_id'];
        $product_id=$productArr['0']['id'];
        $product_name=$productArr['0']['title'];
        $mrp=$productArr['0']['mrp'];
        $image=$productArr['0']['image'];
        $product_quantity=$value['q'];
        $subtotal_price=(int)$product_quantity*(int)$selling_price;

        mysqli_query($con,"INSERT INTO products_ordered (order_id,product_id,default_seller_id,product_quantity,subtotal_price,mrp,selling_price,product_name,image) VALUES ('$order_id','$product_id','$default_seller_id','$product_quantity','$subtotal_price','$mrp','$selling_price','$product_name','$image');");
    }
    
    ?>
    <script>
        window.location.href='thankyou.php';
    </script>
    <?php
}
?>

<div class="container-fluid" style="margin:120px 0 20px 0;">
    <div class="card">
        <div class="card-body" style="padding:0">
            <div class="card-title">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-2" style="background-color:#ffffff;margin-left:30px;font-size:20px">
                        <li class="breadcrumb-item"><a href="index.php"><strong>Home</strong></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><strong>Checkout</strong></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <div class="container">
            <form action="" method="post">
                <div class="row">
                    <div class="col-sm-6">
                        
                            
                            <div class="card" style="margin-bottom:15px">
                                <div class="card-header">
                                    <h6>Basic Account Details</h6>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for="username">Name:</label>
                                        <input type="text" class="form-control disabled" name="buyer_name" id="buyer_name"
                                        placeholder="Enter your name" title="Name should contain Alphabets only" 
                                        pattern="^[A-Za-z -]+$" value="<?php echo $_SESSION['BUYER_NAME'] ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email address:</label>
                                        <input type="email" class="form-control" name="buyer_email" id="buyer_email" aria-describedby="emailHelp"
                                            placeholder="Enter email" title="Enter valid email address" 
                                            value="<?php echo $_SESSION['BUYER_EMAIL'] ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="mobile_number">Mobile Number:</label>
                                        <input type="text" class="form-control" id = "buyer_mobile_number" name = "buyer_mobile_number" 
                                        placeholder="Enter 10 digit Mobile No." title="Please enter your vaild mobile number" required>
                                    </div>
                                </div>
                            </div>

                            <div class="card" style="margin-bottom:15px">
                                <div class="card-header">
                                    <h6>Address Details</h6>
                                </div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="buyer_address_line1" id="buyer_address_line1"
                                        placeholder="Address Line 1: Floor, Building no., Street details" title="Please enter the delivery address" 
                                        required>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="buyer_address_line2" id="buyer_address_line2"
                                        placeholder="Address Line 2: Locality, District and City" title="Please enter the delivery address" 
                                        required>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="buyer_state_ut" id="buyer_state_ut"
                                            placeholder="State or UT" title="Please enter the delivery address" 
                                            required>
                                        </div>
                                        <div class="col-sm-6">
                                            <input type="text" class="form-control" name="buyer_pincode" id="buyer_pincode"
                                            placeholder="Pincode" title="Please enter the delivery address" 
                                            required>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card" style="margin-bottom:15px">
                                <div class="card-header">
                                    <h6>Additional Information</h6>
                                </div>
                                <div class="card-body">
                                    <textarea class="form-control" name="buyer_add_info" id="buyer_add_info" rows=4
                                    placeholder="Additional Information related to delivery timings etc." title="Please enter the delivery address">
                                    </textarea>
                                </div>
                            </div>

                        
                    </div>    
                    <div class="col-sm-6">
                        <div class="card" style="margin-bottom:15px;border:none"">
                            <div class="card-header">
                                <h6>Your Orders</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-stats order-table ov-h">
                                    <table class="table">
                                        <thead>
                                        <tr class="text-center">
                                            <th width="45%" colspan=2>Product</th>
                                            <th width="20%">Basic Price</th>
                                            <th width="12%">GST</th>
                                            <th width="15%">Subtotal</th>
                                            <th width="8%"></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $p_total_price=0;
                                            foreach($_SESSION['cart'] as $key=>$value){
                                                $productArr=get_product_sp($con,'','','',$key);
                                                $p_name=$productArr['0']['title'];
                                                $p_mrp=$productArr['0']['mrp'];
                                                $p_price=$productArr['0']['selling_price'];
                                                $p_image=$productArr['0']['image'];
                                                $p_quantity=$value['q'];
                                                $p_subtotal=(int)$p_quantity*(int)$p_price;                    
                                            ?>
                                        <tr class="text-center">
                                            <td style="padding-right:0;padding-left:0"><div><img src="/ECOM/products_images/<?php echo $p_image ?>" height=80px/></div></td>
                                            <td style="padding-top:2.3rem;padding-left:0;"><?php echo $p_name ?><br/> x <?php echo $p_quantity ?></td>
                                            <td style="padding-top:2.3rem;padding-left:0;">&#8377;<?php echo(round($p_subtotal/1.05,2)) ?></td>
                                            <td style="padding-top:2.3rem">
                                                <!--form><div class="form-group"><input type="number"  width=100px value=<?php echo $p_quantity ?>-->
                                                <!--a href="javascript:void(0)" id="<?php echo $key ?>quantity" onclick="manage_cart('<?php echo $key ?>','update')">
                                                    <small><strong>Update</strong></small>
                                                </a--><!--/div></form-->5%
                                            </td>
                                            <td style="padding-top:2.3rem">&#8377;<?php echo $p_subtotal ?></td>
                                            <td style="padding-top:2.3rem">
                                                <a href="javascript:void(0)" onclick="manage_cart(<?php echo $key ?>,'remove')">
                                                    <i class="fa fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                            <?php
                                            $p_total_price+=$p_subtotal;
                                            }
                                            ?>
                                        <tr class="text-center">
                                            <th colspan=4 style="padding:1.5rem">TOTAL AMOUNT</td>
                                            <th style="padding:1.5rem">&#8377;<?php echo $p_total_price ?></td>
                                            <th style="padding:1.5rem"></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                        </div>
                        <div class="card" style="border:none">
                        <div class="card-body">
                            <div style="margin-top:30px">
                                <input type="submit" value="Place Order" class="btn btn-default3 btn-block" 
                                name="place_order" id="place_order"/>
                            </div>
                        </div>
                    </div> 
                    </div>
                           
                            
                </div>
            </form>
            </div>
        </div>
    </div>
</div>

<?php
require('includes/footer.inc.php');
?>
