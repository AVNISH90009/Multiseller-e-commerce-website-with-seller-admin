<?php

require('includes/connection.inc.php');
require('includes/add_to_cart.inc.php');

$pid=$_POST['pid'];
$q=$_POST['q'];
$type=$_POST['type'];

$obj=new add_to_cart();

if($type=='add'){
    $obj->addProduct($pid,$q);
}

if($type=='remove'){
    $obj->removeProduct($pid);
}

if($type=='update'){
    $obj->updateProduct($pid,$q);
}

echo $obj->totalProduct();
?>