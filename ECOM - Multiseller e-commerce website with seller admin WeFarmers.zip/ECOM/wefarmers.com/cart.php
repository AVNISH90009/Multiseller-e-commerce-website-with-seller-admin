<?php
require('includes/common.inc.php');
?>

<div class="container-fluid" style="margin:120px 0 20px 0;">
    <div class="card">
        <div class="card-body" style="padding:0">
            <div class="card-title">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-2" style="background-color:#ffffff;margin-left:30px;font-size:20px">
                        <li class="breadcrumb-item"><a href="index.php"><strong>Home</strong></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><strong>Cart</strong></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
<div class="card">
<div class="card-body">
<div class="container">
    <div class="table-stats order-table ov-h">
        <table class="table table-bordered">
            <thead>
            <tr class="text-center">
                <th width="18%">Product</th>
                <th width="40%">Product Name</th>
                <th width="14%">Price</th>
                <th width="8%">Quantity</th>
                <th width="15%">Subtotal</th>
                <th width="5%"></th>
            </tr>
            </thead>
            <tbody>
                <?php
                $p_total_price=0;
                foreach($_SESSION['cart'] as $key=>$value){
                    $productArr=get_product_sp($con,'','','',$key);
                    $p_name=$productArr['0']['title'];
                    $p_mrp=$productArr['0']['mrp'];
                    $p_price=$productArr['0']['selling_price'];
                    $p_image=$productArr['0']['image'];
                    $p_quantity=$value['q'];
                    $p_subtotal=(int)$p_quantity*(int)$p_price;                    
                ?>
            <tr class="text-center">
                <td><div><img src="/ECOM/products_images/<?php echo $p_image ?>" height=120px/></div></td>
                <td style="padding-top:3.5rem"><?php echo $p_name ?></td>
                <td style="padding-top:3.5rem">&#8377;<?php echo $p_price ?></td>
                <td style="padding-top:3.5rem">
                    <!--form><div class="form-group"><input type="number"  width=100px value=<?php echo $p_quantity ?>-->
                    <!--a href="javascript:void(0)" id="<?php echo $key ?>quantity" onclick="manage_cart('<?php echo $key ?>','update')">
                        <small><strong>Update</strong></small>
                    </a--><!--/div></form--><?php echo $p_quantity ?>
                </td>
                <td style="padding-top:3.5rem">&#8377;<?php echo $p_subtotal ?></td>
                <td style="padding-top:3.5rem">
                    <a href="javascript:void(0)" onclick="manage_cart(<?php echo $key ?>,'remove')">
                        <i class="fa fa-trash"></i>
                    </a>
                </td>
            </tr>
                <?php
                $p_total_price+=$p_subtotal;
                }
                ?>
            <tr class="text-center">
                <th colspan=4 style="padding:1.5rem">TOTAL AMOUNT</td>
                <th style="padding:1.5rem">&#8377;<?php echo $p_total_price ?></td>
                <th style="padding:1.5rem"></td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col">
            <div style="margin-top:30px">
                <a href="index.php" class="btn btn-default3 btn-block">Continue Shopping</a>
            </div>
        </div>
        <div class="col">
            <div style="margin-top:30px">
            <?php 
                if(isset($_SESSION['BUYER_ID'])){
                    echo '<a href="checkout.php" class="btn btn-default3 btn-block">Checkout</a>';
                }else{
                    echo '<a href="login.php" class="btn btn-default3 btn-block">Checkout</a>';
                } 
            ?>
                
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
<?php
require('includes/footer_product_template.inc.php');
?>