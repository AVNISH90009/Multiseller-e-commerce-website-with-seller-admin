<?php



function prarr($arr){
    echo '<pre>';
    print_r($arr);
    die();
}

function get_product($con,$type='',$limit='',$category_id=''){
    $sql_products = "SELECT * FROM product WHERE status=1";
    if($category_id!=''){
        $sql_products.=" AND categories_id=$category_id";
    }
    if($type=='latest'){
        $sql_products.=" ORDER BY id DESC";
    }
    if($limit!=''){
        $sql_products.=" LIMIT $limit";
    }
    $res_products = mysqli_query($con,$sql_products);
    $products_arr = array();
    while($pro_row = mysqli_fetch_assoc($res_products)){
        $products_arr[]=$pro_row;
    }
    return $products_arr;
}

function get_product_sp($con,$type='',$limit='',$category_id='',$product_id=''){
    $sql_products = "SELECT product.*,categories FROM product,categories WHERE product.status=1";
    if($category_id!=''){
        $sql_products.=" AND product.categories_id=$category_id";
    }
    if($product_id!=''){
        $sql_products.=" AND product.id=$product_id";
    }
    $sql_products.=" AND product.categories_id=categories.id";
    if($type=='latest'){
        $sql_products.=" ORDER BY product.id DESC";
    }
    if($limit!=''){
        $sql_products.=" LIMIT $limit";
    }
    $res_products = mysqli_query($con,$sql_products);
    $products_arr = array();
    while($pro_row = mysqli_fetch_assoc($res_products)){
        $products_arr[]=$pro_row;
    }
    return $products_arr;
}

/*function get_product_sp($con,$type='',$limit='',$category_id='',$product_id=''){
    $sql_products = "SELECT * FROM product WHERE status=1";
    if($category_id!=''){
        $sql_products.=" AND categories_id=$category_id";
    }
    if($product_id!=''){
        $sql_products.=" AND id=$product_id";
    }
    if($type=='latest'){
        $sql_products.=" ORDER BY id DESC";
    }
    if($limit!=''){
        $sql_products.=" LIMIT $limit";
    }
    $res_products = mysqli_query($con,$sql_products);
    $products_arr = array();
    while($pro_row = mysqli_fetch_assoc($res_products)){
        $products_arr[]=$pro_row;
    }
    return $products_arr;
}*/

?>