<?php

require('connection.inc.php');
require('functions.inc.php');
require('add_to_cart.inc.php');

$sql1 = "SELECT * FROM categories WHERE status=1 ORDER BY categories ASC;";
$res1 = mysqli_query($con,$sql1);
$prod_cat = array();
while($row2 = mysqli_fetch_assoc($res1)){
  $prod_cat[] = $row2;
}

$obj=new add_to_cart();
$total_product=$obj->totalProduct();

?>

<!doctype html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php require('includes/bootstrap_link.inc.php'); ?> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <title></title>
</head>

<style>
  .d_d{
    background-color: #ac458b; 
    border: 2px solid white!important; 
    box-shadow: 0 0 10px 1px #7a7a7a;
  }
  .d_d-item{
    color: #ffffff;
  }
  .d_d-item:hover{
    background-color: #aa207f;
    color: #ffffff;
  }
</style>

<body>
  
    <nav class="navbar navbar-expand-lg fixed-top" style="background-color: #77003add; padding:5px; margin:0; z-index:1051;">
      <div class="container-fluid">
        <div>
          <a class="navbar-brand" href="index.php" style="color: #ffffff;">
            <h1 class="header-logo" style="margin-top:-10px!important"><strong>WeFarmers</strong></h1>
          </a>
        </div>
        
        
        <center>
          <div class="collapse navbar-collapse">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="padding-left: ">
                <li class="nav-item nav_select">
                    <form class="form-inline">
                      <input class="form-control mr-sm-0" type="search" placeholder="Search" aria-label="Search" style="width: 30rem; border-radius: 30px 0px 0px 30px">
                      <button class="btn btn-warning my-2 my-sm-0" type="submit" style="border-radius: 0px 30px 30px 0px">Search</button>
                    </form>
                </li>
            </ul>
          </div>
        </center>
        <div>
          <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
            
              <li class="nav-item dropdown btn btn-default2">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" 
                aria-haspopup="true" aria-expanded="false" style="color: #ffffff; margin-top:0;">
                  More
                </a>
                <div class="dropdown-menu d_d" aria-labelledby="navbarDropdown" id="more_dropdown" 
                style="">
                  <?php if(isset($_SESSION['BUYER_ID'])){ ?>
                  <a class="dropdown-item d_d-item" href="your_orders.php">Your Orders</a>
                  <div class="dropdown-divider"></div>
                  <?php }else{} ?>
                  <a class="dropdown-item d_d-item" href="/ECOM/index.php" target="_blank" rel="noopener noreferrer">Sell on WeFarmers</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item d_d-item" href="#">Support</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item d_d-item" href="#">Notification preferences</a>
                </div>
              </li>

              <?php if(isset($_SESSION['BUYER_NAME'])){ ?>
                <li class="nav-item dropdown btn btn-default2">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" 
                aria-haspopup="true" aria-expanded="false" style="color: #ffffff; margin-top:0;">
                  Hi! <?php echo $_SESSION['BUYER_NAME']; ?>
                </a>
                <div class="dropdown-menu d_d" aria-labelledby="navbarDropdown" id="more_dropdown" 
                style="">
                  
                  <a class="dropdown-item d_d-item" href="your_orders.php">Your Orders</a>
                  <div class="dropdown-divider"></div>
                  
                  <a class="dropdown-item d_d-item" href="logout.php">Logout</a>
                </div>
              </li>
              <?php }else{ ?>
              <li class="nav-item  btn btn-default7" style="margin-top:5px">
                <a class="nav-link" href="login.php" style="color: white; margin-top:0">Login</a>
              </li>
              
              <?php } ?>
              <li class="nav-item  btn btn-default7" style="margin-top:">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <a class="nav-link" href='cart.php' style="color: white; margin-top:0px; font-size:20px" title="cart">
                  <i class="fa fa-shopping-cart" id="cart-icon" title="cart"></i>
                  <span class="cart-basket d-flex align-items-center justify-content-center" 
                  style="color:#000000;margin-top:-38px;margin-left:20px;font-size:14px;background:#fab005;border-radius:50%;width:20px"><?php echo $total_product ?></span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <nav class="navbar navbar-expand-lg fixed-top" 
    style="background-color: #aa207fdd; padding: 0; box-shadow: 0 10px 20px 4px #7a7a7a7a; margin-top:71px">
      <div class="container-fluid">
        <div class="collapse navbar-collapse">
          <center>
            <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="padding-left: ">
              
                <li class="nav-item nav_select">
                  <a class="c_c nav-link active" aria-current="page" href="index.php" style = "color:white">All</a>
                </li>     
<?php 
foreach($prod_cat as $list_product_category){
?>
              <li class="nav-item nav_select">
                <a class="c_c nav-link active" aria-current="page" href="category.php?id=<?php echo($list_product_category['id']); ?>" 
                style = "color:white"><?php echo($list_product_category['categories']); ?></a>
              </li>
<?php
}
?>        
            </ul>
          </center>
        </div>
        <div>
          <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
              <li class="nav-item" style="margin-top:3px">
                <a class="nav-link disabled" style="color: white;"></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>