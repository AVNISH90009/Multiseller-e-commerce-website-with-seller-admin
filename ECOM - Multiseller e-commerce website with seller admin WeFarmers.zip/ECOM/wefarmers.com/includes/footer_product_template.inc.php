   <footer>
      <div class="card" style="border:none!important; background-color: #ffffff;">
         <div class="card-body">
            <div class="container">
               <div class="row" style="align: right!important; padding-top: 20px">
                     <div class="col-sm-5"></div>
                     <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Terms of Services</p></div>
                     <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Privacy Policy</p></div>
                     <div class="col-sm-3"><p style="font-size: 12px; color: #7a7a7a">Copyright 2021, WeFarmers</p></div>
               </div>
            </div>
         </div>
      </div>
   </footer>

   <?php require('includes/bootstrap_js.inc.php'); ?>
   
   <script src="js/owl.carousel.min.js"></script>
   <script>
      $(document).ready(function(){
         $('.owl-carousel').owlCarousel();
      })
   </script>

</body>
</html>