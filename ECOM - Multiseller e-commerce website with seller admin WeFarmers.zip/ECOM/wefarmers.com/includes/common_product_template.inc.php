<?php
require('connection.inc.php');
require('functions.inc.php');

$sql1 = "SELECT * FROM categories;";
$res1 = mysqli_query($con,$sql1);


?>

<!doctype html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php require('includes/bootstrap_link.inc.php'); ?> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="css/owl.carousel.css"/>
  <link rel="stylesheet" href="css/owl.theme.green.css"/>
  <title></title>
</head>

<style>
  .d_d{
    background-color: #ac458b; 
    border: 2px solid white!important; 
    box-shadow: 0 0 10px 1px #7a7a7a;
  }
  .d_d-item{
    color: #ffffff;
  }
  .d_d-item:hover{
    background-color: #aa207f;
    color: #ffffff;
  }
</style>

<body>
  
    <nav class="navbar navbar-expand-lg fixed-top" style="background-color: #77003a; padding: 5px; z-index:1051;">
      <div class="container-fluid">
        <div>
          <a class="navbar-brand" href="dashboard.php" style="color: White;">
            <h1 class="header-logo"><strong>WeFarmers</strong></h1>
          </a>
        </div>
        <center>
          <div class="collapse navbar-collapse">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="padding-left: ">
                <li class="nav-item nav_select">
                    <form class="form-inline">
                      <input class="form-control mr-sm-0" type="search" placeholder="Search" aria-label="Search" style="width: 30rem; border-radius: 30px 0px 0px 30px">
                      <button class="btn btn-warning my-2 my-sm-0" type="submit" style="border-radius: 0px 30px 30px 0px">Search</button>
                    </form>
                </li>
            </ul>
          </div>
        </center>
        <div>
          <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
              <li class="nav-item dropdown btn btn-default2">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" 
                aria-haspopup="true" aria-expanded="false" style="color: white; margin-top:0px;">
                  More
                </a>
                <div class="dropdown-menu d_d" aria-labelledby="navbarDropdown" id="more_dropdown" 
                style="">
                  <a class="dropdown-item d_d-item" href="/ECOM/index.php">Sell on WeFarmers</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item d_d-item" href="#">Support</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item d_d-item" href="#">Notification preferences</a>
                </div>
              </li>
              <li class="nav-item" style="margin-top:3px">
                <a class="nav-link disabled" style="color: white; margin-top:5px">Hello, Sign in</a>
              </li>
              <li class="nav-item dropdown">
                <a href="#" class="btn" data-toggle="dropdown" aria-haspopup="false" 
                aria-expanded="false" role="button" id="user_button" area-disabled="true">
                  <img src="/ECOM/images/user_farmer.jpg" width="45px" style="border-radius:50%">
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="border:2px solid #fab005;">
                    <a class="dropdown-item" href="updateprofile.php">Update Profile</a>
                    <div class="dropdown-divider" style="border:1px solid #fab005;"></div>
                    <center>
                      <a class="dropdown-item" href="logout.php">
                        <a href="logout.php" class="btn btn-outline-danger" role="button" aria-disabled="true">
                          Logout
                        </a>
                      </a>
                    </center>
                  </div>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>

    <nav class="navbar navbar-expand-lg fixed-top" 
    style="background-color: #aa207f; padding: 0; box-shadow: 0 10px 20px 4px #7a7a7a7a; margin-top:67px">
      <div class="container-fluid">
        <div class="collapse navbar-collapse">
        <center>
          <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="padding-left: ">
            
              <!--li class="nav-item nav_select">
                <a class="c_c nav-link active" aria-current="page" href="index.php" style = "color:white">All</a>
              </li>
              <li class="nav-item nav_select">
                <a class="c_c nav-link active" aria-current="page" href="dashboard.php" style = "color:white">Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="products.php" style = "color:white">Products</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="orders.php" style = "color:white">Orders</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="payments.php" style = "color:white">Payments</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="contact_us.php" style = "color:white">Conversations</a>
              </li-->
        <?php
            $i=0;
            while($row_set1 = mysqli_fetch_assoc($res1)){
                $i++;?>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="#" style = "color:white"><?php echo $row_set1['categories']; ?></a>
              </li>    
        <?php } ?>
            
          </ul>
          </center>
        </div>
        <div>
          <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
              <li class="nav-item" style="margin-top:3px">
                <a class="nav-link disabled" style="color: white;"></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>