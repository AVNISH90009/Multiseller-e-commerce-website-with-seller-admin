<?php require('includes/connection.inc.php');

$buyer_name = $_POST['buyer_name'];
$buyer_email = $_POST['buyer_email'];
$buyer_password = $_POST['buyer_password'];
$cpassword = $_POST['cpassword'];
$added_on = date('Y-m-d h:i:s');

$buyer_check = "SELECT * FROM buyer_details WHERE buyer_email='$buyer_email'";
$check = mysqli_query($con,$buyer_check);
$x=mysqli_num_rows($check);

if($x==0){

    $buyer_reg_sql = "INSERT INTO buyer_details (buyer_name,buyer_email,added_on,buyer_password) VALUES ('$buyer_name','$buyer_email','$added_on','$buyer_password');";

    if($buyer_password == $cpassword){
        if(!mysqli_query($con,$buyer_reg_sql)){
            echo "Not Inserted";
        }else{
            echo "Registration Successful";
        }
        header ("refresh:2;url = login.php");
    }else{
        echo "password do not match";
        header ("refresh:2;url = register.php");
    }

}else{
    echo "Email already exists";
    header ("refresh:2;url = register.php");
}

?>

