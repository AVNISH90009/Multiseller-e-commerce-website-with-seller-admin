<?php
require('includes/common.inc.php');
$category_id=mysqli_real_escape_string($con,$_GET['id']);
$get_product=get_product_sp($con,'latest',12,$category_id);
?>

<style>
a.custom-card,
a.custom-card:hover {
  color: inherit;
  text-decoration:none;
}
</style>

<div class="container-fluid" style="margin:120px 0 20px 0;">
    <div class="card">
        <div class="card-body" style="padding:0">
            <div class="card-title">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-2" style="background-color:#ffffff;margin-left:30px;font-size:20px">
                        <li class="breadcrumb-item"><a href="index.php"><strong>Home</strong></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><strong>Products</strong></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid" style="margin:-10px 0 20px 0;">
    <div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <!--div class="card-header">
                        <h6> Products </h6>
                    </div-->
                    <div class="card-body">

                        <?php 
                        $i=-1;
                        
                        if(count($get_product)>0){
                        foreach($get_product as $products_rows)
                        {
                            $i++;
                            if($i%4==0){
                                echo "<div class='row' style='margin-bottom:20px'>";
                            }else{}
                        ?>
                            <div class="col-sm-3">
                                <a href="farmproduct.php?id=<?php echo $products_rows['id'];?>" class="custom-card" target="_blank" rel="noopener noreferrer">
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                            
                                            <center><img src="/ECOM/products_images/<?php echo $products_rows['image'];?>" width=200px/></center>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6><?php echo $products_rows['title'];?></h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j><?php echo $products_rows['selling_price'];?> <j style="font-size: 15px; color: grey"><del>&#8377;<?php echo $products_rows['mrp'];?></del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;
                                                    <?php 
                                                        $saving = $products_rows['mrp']-$products_rows['selling_price'];
                                                        echo $saving;
                                                    ?> (<?php $percent_saving = round(($saving/$products_rows['mrp'])*100); echo $percent_saving?>%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="farmproduct.php?id=<?php echo $products_rows['id'];?>" class="btn btn-default1" target="_blank" rel="noopener noreferrer">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </a>
                            </div>
                        <?php 
                        if(($i+1)%4==0){
                            echo "</div>";
                        }else{}
                        }
                     }else{echo "Products not found";} ?>
                        
                <?php /*
                $i=-1;
                while($products_rows = mysqli_fetch_assoc($products)){
                    $i++;
                    if($i%4 == 0){ ?>
                        <div class="row" style="margin-bottom:20px">
                <?php
                    }else{}
                ?>        
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                           
                                            <center><img src="/ECOM/products_images/<?php echo $products_rows['image'];?>" width=200px/></center>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6><?php echo $products_rows['name'];?></h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j><?php echo $products_rows['selling_price'];?> <j style="font-size: 15px; color: grey"><del>&#8377;<?php echo $products_rows['mrp'];?></del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;
                                                    <?php 
                                                        $saving = $products_rows['mrp']-$products_rows['selling_price'];
                                                        echo $saving;
                                                    ?> (<?php $percent_saving = round(($saving/$products_rows['mrp'])*100); echo $percent_saving?>%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="#" class="btn btn-default1">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                <?php
                            if(($i+1)%4 == 0){ 
                ?>
                        </div>
                <?php
                    }else{}
                ?>      

                        <?php } */?>

                        
                        <!--div class="row">
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                            <img src="/ECOM/products_images/6_46932543_of10.png" width=150px/>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6>Bitter Guard 1 kg</h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j>20 <j style="font-size: 15px; color: grey"><del>&#8377;45</del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;25 (55%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="#" class="btn btn-default1">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                            <img src="/ECOM/products_images/6_46932543_of10.png" width=150px/>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6>Bitter Guard 1 kg</h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j>20 <j style="font-size: 15px; color: grey"><del>&#8377;45</del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;25 (55%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="#" class="btn btn-default1">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    <!--?php
                    $x = 2;
                    if ($x == 2){ ?>
                        </div>
                        <div class="row">
                    <!--?php }else{} ?>    
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                            <img src="/ECOM/products_images/6_46932543_of10.png" width=150px/>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6>Bitter Guard 1 kg</h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j>20 <j style="font-size: 15px; color: grey"><del>&#8377;45</del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;25 (55%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="#" class="btn btn-default1">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                            <img src="/ECOM/products_images/6_46932543_of10.png" width=150px/>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6>Bitter Guard 1 kg</h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j>20 <j style="font-size: 15px; color: grey"><del>&#8377;45</del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;25 (55%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="#" class="btn btn-default1">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div-->
                        
                    </div>
                </div>
            </div>

            <!--div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h6>Latest Products</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                        <?php /* $get_product=get_product($con,"latest",4);
                        foreach($get_product as $list){
                        ?>
                            <div class="col-sm-3">
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                            <img src="/ECOM/products_images/<?php echo $list['image'] ?>" width=150px/>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6><?php echo $list['name'] ?></h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j><?php echo $list['selling_price'] ?> <j style="font-size: 15px; color: grey"><del>&#8377;<?php echo $list['mrp'] ?></del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;<?php $saving=$list['mrp']-$list['selling_price']; echo $saving ?> (<?php echo(round(($saving/$list['mrp'])*100)) ?>%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="#" class="btn btn-default1">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>                            
                            </div>
                        <?php } */?>
                        </div>
                    </div>
                </div>
            </div-->
        </div>
    </div>
</div>  

<?php
require('includes/footer.inc.php');
?>