<?php
require('includes/common.inc.php');
$product_id=mysqli_real_escape_string($con,$_GET['id']);
$get_product=get_product_sp($con,'','','',$product_id);
?>

<style>
    h4{
        color:green;
    }
    h5{
        color:Brown;
    }
    .fa {
    padding: 12px;
    font-size: 16px;
    width: 40px;
    text-align: center;
    text-decoration: none;
    margin: 3px 3px;
    border-radius: 50%;
    }

    .fa:hover {
        opacity: 0.7;
    }

    .fa-shopping-cart{
        margin: 0; 
        padding: 0;
        text-align: default;
        width: default;
        border-radius: none;
    }

    .fa-facebook {
    background: #3B5998;
    color: white;
    }

    .fa-twitter {
    background: #55ACEE;
    color: white;
    }

    .fa-linkedin {
    background: #007bb5;
    color: white;
    }

    .fa-instagram {
    background: #125688;
    color: white;
    }

    .fa-pinterest {
    background: #cb2027;
    color: white;
    }

    a.custom-card,
    a.custom-card:hover {
    color: inherit;
    text-decoration:none;
    }

</style>

<div class="container-fluid" style="margin:120px 0 20px 0;">
    <div class="card">
        <div class="card-body" style="padding:0">
            <div class="card-title">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-2" style="background-color:#ffffff;margin-left:30px;font-size:20px">
                        <li class="breadcrumb-item"><a href="index.php"><strong>Home</strong></a></li>
                        <li class="breadcrumb-item"><a href="category.php?id=<?php echo $get_product['0']['categories_id'] ?>"><strong><?php echo $get_product['0']['categories'] ?></strong></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><strong><?php echo $get_product['0']['title'] ?></strong></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid" style="margin:-10px 0 20px 0">
    <div class="row"> 
        <div class="col-sm-9">
            <div class='card'>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <img src="/ECOM/products_images/<?php echo $get_product['0']['image'] ?>" width=400px>
                        </div>
                        <div class="col-sm-6">
                            <h2><?php echo $get_product['0']['title'] ?></h2>
                            
<?php 
if($get_product['0']['qty']>2){
echo "<h4>In stock</h4>";
}elseif($get_product['0']['qty']>0){
echo "<h4>Only ".$get_product['0']['qty']." left in stock</h4>";
}else{
echo "<h4 style='color:red;'>Out of Stock</h4>";
}
                            ?>                           
                            <p>Sold by Farmer</p>
                            <hr/>
                            <table>
                                <tr style="padding-top:0;">
                                    <td style="text-align: right; color: #7a7a7a">MRP:</td>
                                    <td style="color: #7a7a7a; padding-left:10px; padding-top:0"><del>&#8377;<?php echo $get_product['0']['mrp'] ?></del></td>
                                </tr>
                                <tr style="padding-top:0;">
                                    <td style="text-align: right; color: #7a7a7a">Deal Price:</td>
                                    <td><p style="font-size: 25px; color: #aa207f;padding-left:10px;margin-bottom:0"><j style="font-size: 18px;"><sup><strong>&#8377;</strong></sup></j><?php echo $get_product['0']['selling_price'] ?></p></td>
                                </tr>
                                <tr style="padding-top:0;">
                                    <td style="text-align: right; color: #7a7a7a">You Save:</td>
                                    <td style="color: #7a7a7a;padding-left:10px; padding-top:0">&#8377;<?php 
                                    $saving=$get_product['0']['mrp']-$get_product['0']['selling_price']; echo $saving;?> (<?php $percent_saving = round(($saving/$get_product['0']['mrp'])*100); echo $percent_saving?>%)</td>
                                </tr>
                            </table>
                            <br/>
                            <h5>Free Delivery</h5>
                            <p>Delivery time: <strong>After 3 days from date of order</strong></p>
                            <table>
                                <tr>
                                    <th style="max-width:120px;padding:6px">Category</th>
                                    <td style=""><?php echo $get_product['0']['categories'] ?></td>
                                </tr>
                                <tr>
                                    <th style="max-width:120px;padding:6px">Weight</th>
                                    <td style=""><?php echo $get_product['0']['weight'] ?> kilograms</td>
                                </tr>
                                    <th style="max-width:120px;padding:6px">Item Dimension LxWxH</th>
                                    <td style=""><?php echo $get_product['0']['length'] ?> x <?php echo $get_product['0']['width'] ?> x <?php echo $get_product['0']['height'] ?> Centimeters</td>
                                </tr>
                            </table>
                            
                            <div class="card">
                                <div class="card-header">
                                    <h6>Short Description</h6>
                                </div>
                                <div class="card-body">
                                    <p><?php echo $get_product['0']['short_desc'] ?></p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <br/>
                    <div class="row">
                        <div class="col-sm-12">
                        <div class="card">
                                <div class="card-header">
                                    <h6>Long Description</h6>
                                </div>
                                <div class="card-body">
                                    <p><?php echo $get_product['0']['description'] ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-3">
            <div class="card">
                <div class="card-body">
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                    <h6>Share Now</h6>
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-linkedin"></a>
                    <a href="#" class="fa fa-instagram"></a>
                    <a href="#" class="fa fa-pinterest"></a>
                    <hr/>
                    <br>
                    <div class="row">
                        <div class="col-auto">
                            <h6>Select Order Quantity:</h6>
                        </div>
                        <div class="col-auto">
                            <select id="q">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                            </select>
                        </div>
                    </div>
                    <div style="margin-top:30px">
                        <!--a href="javascript:void(0)" onclick="manage_cart('<?php echo $get_product['0']['id'] ?>','add')" class="btn btn-default6 btn-block">Add to Cart</a-->
                        <a href="cart.php" onclick="manage_cart('<?php echo $get_product['0']['id'] ?>','add')" class="btn btn-default6 btn-block">Add to Cart</a>
                    </div>
                    <div style="margin-top:30px">
                        <a href="#" class="btn btn-default3 btn-block">Order Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mb-3" style="background-color:#ffffff">
    <div class="card">
        <div class="card-header">
            <h4 style="color:#000">Related Products</h4>
        </div>
        <div class="card-body">
            <div class="row">
            
                        <?php $get_product=get_product($con,"latest",6);
                        foreach($get_product as $list){
                        ?>
                        
                            <a href="farmproduct.php?id=<?php echo $list['id'];?>" class="custom-card" target="_blank" rel="noopener noreferrer">
                            
                            <div class="col-sm-2">
                            
                                <div class="card">
                                    <div class="card-body" style="margin-top: 10px; margin-bottom:0">
                                        <div>
                                            <img src="/ECOM/products_images/<?php echo $list['image'] ?>" width=150px/>
                                        </div>
                                        <div style="text-align:center; margin-top: 20px">
                                            <div>
                                                <h6><?php echo $list['title'] ?></h6>
                                            </div>
                                            <div>
                                                <p style="font-size: 30px; color: #aa207f"><j style="font-size: 22px;"><sup><strong>&#8377;</strong></sup></j><?php echo $list['selling_price'] ?> <j style="font-size: 15px; color: grey"><del>&#8377;<?php echo $list['mrp'] ?></del></j></p>
                                                <p style="font-size: 15px; margin-top: -20px"> Save &#8377;<?php $saving=$list['mrp']-$list['selling_price']; echo $saving ?> (<?php echo(round(($saving/$list['mrp'])*100)) ?>%)</p>
                                            </div>
                                            <div style="margin-top:30px">
                                                <a href="farmproduct.php?id=<?php echo $list['id'];?>" class="btn btn-default1" target="_blank" rel="noopener noreferrer">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>  
                                                          
                            </div>
                         
                            </a>
                        <?php } ?>
                        
                </div>
            
            </div>
        </div>
    </div>
</div>

    

<?php
require('includes/footer_product_template.inc.php');
?>

