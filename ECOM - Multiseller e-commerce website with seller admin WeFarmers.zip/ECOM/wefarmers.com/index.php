<?php
require('includes/common.inc.php');

$sql="SELECT * FROM product WHERE status=1 ORDER BY id DESC;";
$products=mysqli_query($con,$sql);

?>
<div class="container-fluid" style="margin:120px 0 20px 0;">
    <div class="card">
        <div class="card-body" style="padding:0">
            <div class="card-title">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-2" style="background-color:#ffffff;margin-left:30px;font-size:20px">
                        <li class="breadcrumb-item active" aria-current="page"><strong>Home</strong></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid" style="margin:-10px 0 20px 0">
    <div>
        <div class="row">
            <!--div class="col-sm-3">
                <div class="card">
                    <div class="card-header">
                        <h6> Filter </h6>
                    </div>
                    <div class="card-body">
                        <p> <p><?php print_r($products); ?></p> </p>
                    </div>
                </div>
            </div-->

            <?php require('includes/products.inc.php'); ?>
            
        </div>
    </div>
</div-->  

<?php
require('includes/footer.inc.php');
?>