function manage_cart(pid,type){
	if(type=='update'){
		var q=jQuery("#"+pid+"quantity").val();
	}else{
		var q=jQuery("#q").val();
	}
	jQuery.ajax({
		url:'manage_cart.php',
		type:'post',
		data:'pid='+pid+'&q='+q+'&type='+type,
		success:function(result){
			if(type=='update' || type=='remove'){
				window.location.href='cart.php';
			}
			jQuery('.cart-basket').html(result);
		}	
	});	
}