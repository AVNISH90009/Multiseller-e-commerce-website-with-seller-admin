<?php
require('includes/common.inc.php');

$buyer_id = $_SESSION['BUYER_ID'];

$sql1 = "SELECT * FROM orders WHERE buyer_id='$buyer_id' ORDER BY order_id DESC;";

$buyer_orders = mysqli_query($con,$sql1);

?>

<style>
h6.light-grey{
    color:#7a7a7a!important;
    font-size:13px;
    padding:0;
    margin:0;
}

h6.small-black{
    
    font-size:13px;
    padding:0;
    margin-top:8px;
}
.noborder{
    border:none;
}
</style>

<div class="container-fluid" style="margin:120px 0 20px 0;">
    <div class="card">
        <div class="card-body" style="padding:0">
            <div class="card-title">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mt-2" style="background-color:#ffffff;margin-left:30px;font-size:20px">
                        <li class="breadcrumb-item"><a href="index.php"><strong>Home</strong></a></li>
                        <li class="breadcrumb-item active" aria-current="page"><strong>Your Orders</strong></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="card noborder" style="background-color:#00000000">
        <div class="card-body">
            <div class="container">
                
                        <?php
                        while($order_rows=mysqli_fetch_assoc($buyer_orders)){ ?>
                            <div class="row">
                                <div class="col-sm-12">
                                <div class="card" style="margin-bottom:20px">
                    <div class="card-body">
                    <div class="card-title" style="padding-left:20px">
                                                <h4 style="color:#aa207f">Order Code # <?php echo $order_rows['buyer_id']; ?>-<?php echo $order_rows['order_id']; ?>-<?php echo date("dmy",strtotime($order_rows['added_on'])); ?>-<?php echo date("his",strtotime($order_rows['added_on'])); ?></h4>
                                                <p style="font-size:12px"><?php echo date("d M, Y h:i a",strtotime($order_rows['added_on'])); ?></p>
                                            </div>
                                <div class="row">
                                <div class="col-sm-4">
                                    <div class="card noborder" style="margin-bottom:15px">
                                        <div class="card-body">
                                            <h5>Delivery Address:</h5>
                                            <h6><?php echo $order_rows['buyer_name']; ?></h6>
                                            <h6 class="light-grey"><?php echo $order_rows['buyer_address_line1']; ?></h6>
                                            <h6 class="light-grey"><?php echo $order_rows['buyer_address_line2']; ?></h6>
                                            <h6 class="light-grey"><?php echo $order_rows['buyer_state_ut']; ?></h6>
                                            <h6 class="light-grey"><?php echo $order_rows['buyer_pincode']; ?></h6>
                                            
                                            <h6 class="small-black">Phone No. <?php echo $order_rows['buyer_mobile_number']; ?></h6>
                                            <h6 class="light-grey">Order Status: <?php echo $order_rows['order_status']; ?></h6>
                                            <h6 class="small-black">Total Order Value: &#8377;<?php echo $order_rows['total_price']; ?></h6>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="col-sm-8">
                                    
                                            <?php
                                                $x=$order_rows['order_id'];
                                                $sql2 = "SELECT * FROM products_ordered WHERE order_id=$x;";
                                                $productss_ordered = mysqli_query($con,$sql2);
                                                while($productss_ordered_row = mysqli_fetch_assoc($productss_ordered)){ ?>
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <div class="card noborder">
                                                                <div class="card-body">
                                                                    <div>
                                                                        <img src="/ECOM/products_images/<?php echo $productss_ordered_row['image']; ?>" height=160px/>
                                                                    </div>
                                                                </div>
                                                            </div>   
                                                        </div>
                                                        <div class="col-sm-8">
                                                            <div class="card noborder">
                                                                <div class="card-body">
                                                                    <div>
                                                                        <h6 style="margin-top:0px"><strong><?php echo $productss_ordered_row['product_name']; ?></strong></h6>
                                                                        
                                                                    </div>
                                                                </div>
                                                            </div>   
                                                        
                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="card noborder">
                                                                    <div class="card-body">
                                                                        <div>
                                                                            
                                                                            <h6 class="small-black" style="margin-top:0px;margin-bottom:5px">Product MRP:</h6>
                                                                            <h6 class="light-grey">&#8377;<?php echo $productss_ordered_row['mrp']; ?></h6>
                                                                            <h6 class="small-black" style="margin-top:20px;margin-bottom:5px">Product Price:</h6>
                                                                            <h6 class="light-grey">&#8377;<?php echo $productss_ordered_row['selling_price']; ?></h6>
                                                                        </div>
                                                                    </div>
                                                                </div>   
                                                            </div>
                                                            <div class="col">
                                                                <div class="card noborder">
                                                                    <div class="card-body">
                                                                        <div>
                                                                            <h6 class="small-black" style="margin-top:0px;margin-bottom:5px">Quantity Purchased:</h6>
                                                                            <h6 class="light-grey"><?php echo $productss_ordered_row['product_quantity']; ?></h6>
                                                                            <h6 class="small-black" style="margin-top:20px;margin-bottom:5px">Subtotal Price:</h6>
                                                                            <h6 class="light-grey">&#8377;<?php echo $productss_ordered_row['subtotal_price']; ?></h6>
                                                                        </div>
                                                                    </div>
                                                                </div>   
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    
                                                    </div>
                                                <div><hr/></div>
                                                <?php }
                                                
                                            ?>
                                     </div>
                                    </div>   
                                </div>
                            </div>
                            </div>
                            </div>                 
                        <?php }
                        ?>
                    
            </div>
        </div>
    </div>
</div>


<?php
require('includes/footer.inc.php');
?>