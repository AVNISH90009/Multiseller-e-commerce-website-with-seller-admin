<?php

//Connecting to Server to access the database

$newusercon = mysqli_connect('localhost','root','');  
if (!$newusercon)	{
	echo "Not connected to Server";
}

//Selecting the farmers_ecommerce database
if (!mysqli_select_db($newusercon,'farmers_ecommerce'))	{
	echo "Database not selected";
}
//To collect the form data using POST method

$Username = $_POST['user_id'];	
$Full_name = $_POST['name'];	
$Gender = $_POST['gender'];
$DOB = $_POST['dob'];
$Mobile_number = $_POST['mobile_number'];
$PAssword = $_POST['password'];
$Cpassword = $_POST['cpassword'];

//SQL quert to insert rows in table new_user

$sql = "INSERT INTO new_user (user_id,name,gender,dob,mobile_number,password,cpassword) VALUES ('$Username','$Full_name','$Gender','$DOB','$Mobile_number','$PAssword','$Cpassword');";

//If password and confirm password match, registration successful and redirected to login.php else fail.

if ($PAssword == $Cpassword)
{
	if (!mysqli_query($newusercon,$sql))
	{
		echo "Not Inserted";
	}
	else
	{
		echo "Congratulations!!! Registration Successful. Kindly login to access your account.";
	}
	header ("refresh:3; url = login.php");
}
else
{
	echo("Passwords do not match");
	header ("refresh:3; url = farmer_registration.php");
}

?>
