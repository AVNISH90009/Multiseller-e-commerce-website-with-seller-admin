<?php
require('connection.inc.php');
require('functions.inc.php');
if(!isset($_SESSION['user_id'])){
	header("Location:Login.php");
}
?>

<!doctype html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php require('includes/bootstrap_link.inc.php'); ?> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/common.inc.css">
  <title></title>
</head>

<body>
  <header>
    <nav class="navbar navbar navbar-expand-lg fixed-top" 
    style="background-color: #aa207f; padding: 10px; box-shadow: 0 0 20px 4px #7a7a7a">
      <div class="container-fluid">
        <div>
          <a class="navbar-brand" href="dashboard.php" style="color: #ffffff;">
            <h1 class="header-logo"><strong>WeFarmers</strong></h1>
            <h1 class="header-logo">Seller Central</h1>
          </a>
        </div>
        <div class="collapse navbar-collapse">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="padding-left: 180px">
              <li class="nav-item nav_select">
                <a class="c_c nav-link active" aria-current="page" href="dashboard.php" style = "color:#ffffff">Dashboard</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="products.php" style = "color:#ffffff">Products</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="orders.php" style = "color:#ffffff">Orders</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="payments.php" style = "color:#ffffff">Payments</a>
              </li>
              <li class="nav-item">
                <a class="c_c nav-link active" aria-current="page" href="contact_us.php" style = "color:#ffffff">Conversations</a>
              </li>
          </ul>
        </div>
        <div>
          <div class="collapse navbar-collapse">
            <ul class="navbar-nav">
              <li class="nav-item" style="margin-top:3px">
                <a class="nav-link disabled" style="color: white;">Welcome! <?php echo $_SESSION['name'] ?></a>
              </li>
              <li class="nav-item dropdown">
                <a href="#" class="btn btn-default1" data-toggle="dropdown" aria-haspopup="false" 
                aria-expanded="false" role="button" id="user_button" area-disabled="true">
                  <img src="images/user_farmer.jpg" width="45px" style="border-radius:50%">
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown" style="border:2px solid #fab005;">
                    <a class="dropdown-item" href="updateprofile.php">Update Profile</a>
                    <div class="dropdown-divider" style="border:1px solid #fab005;"></div>
                    <center>
                      <a class="dropdown-item" href="logout.php">
                        <a href="logout.php" class="btn btn-outline-danger" role="button" aria-disabled="true">
                          Logout
                        </a>
                      </a>
                    </center>
                  </div>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  </header>
  
  

