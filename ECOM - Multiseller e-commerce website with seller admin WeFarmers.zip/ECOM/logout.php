<?php
session_start();
$_SESSION['default_id'] = '';
$_SESSION['user_id'] = '';
$_SESSION['name'] = '';
$_SESSION['gender'] = '';
$_SESSION['dob'] = '';
$_SESSION['mobile_number'] ='';
unset($_SESSION['default_id']);
unset($_SESSION['user_id']);
unset($_SESSION['name']);
unset($_SESSION['gender']);
unset($_SESSION['dob']);
unset($_SESSION['mobile_number']);
//session_destroy();
header('location:login.php')
?>