<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <?php require('includes/bootstrap_link.inc.php'); ?>

  <title>WeFarmers Seller Central</title>
</head>

<body>
  <!--code starts here-->
  <!-- Image and text -->
  <nav class="navbar fixed-top" style="background-color: #aa207f">
    <div class="container">
      <div>
        <a class="navbar-brand" href="index.php" style="color: White;">
          <h1 class="header-logo"><strong>WeFarmers</strong></h1>
          <h1 class="header-logo">Seller Central</h1>
        </a>
      </div>
      <div>
        <a href="login.php" class="btn btn-default2">Login</a>
        <a href="farmer_registration.php" class="btn btn-default1">Sign Up</a>
      </div>
    </div>
  </nav>

  <div style="background-color: #aa207f">
    <div class="container">
      <div class="col-sm-7" style="padding-top: 8rem; margin-left:-16px">
        <h1 style="color: white; font-size:70px;">Become a WeFarmer Seller</h1>
      </div>
    </div>
  </div>

  <div style="margin-top: -10px;">
    <div style="background-color: #aa207f">
      <div class="container">
        <div class="row">
          <div class="col-sm-7" style="padding-top: 3rem; padding-bottom: 6rem;">
            <p style="color: white; font-size: 15px">Almost all the units sold in our stores are from 
              independent Farmers.</p><p style="color: white; font-size: 15px; letter-spacing: 2px;">ONLY FARMERS ARE ELIGIBLE</p>
            <a href="/ECOM/wefarmers.com/index.php" class="btn btn-default3" id="learnmorebtn" target="_blank" rel="noopener noreferrer">Visit our SHOP</a>
          </div>
          <div class="col-sm-5" style="margin-top: -8rem; padding-bottom: 6rem;">
            <img src="images/greenleaves.png" width="450px" style="transform: rotate(-40deg)">
          </div>
        </div>
      </div>
    </div>
    <div style="margin-top: -273px; padding-bottom: 100px">
      <svg alt="" class="wave-placement-bottom wave-flip" height="278px" preserveAspectRatio="none" role="presentation"
        version="1.1" viewBox="0 0 1440 278" width="1440px" xmlns="http://www.w3.org/2000/svg">
        <g id="Sandbox" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <path d="M0,260.670469 C268,291.980818 533.333333,258.847538 796,161.270627 C1058.66667,63.6937169 
            1273.33333,9.93684108 1440,0 L1440,278 L0,278 L0,260.670469 Z" id="Path-8" fill="#ffffff"
            transform="translate(720.000000, 139.000000) scale(1, 1) translate(-720.000000, -139.000000) ">
          </path>
        </g>
      </svg>
    </div>
  </div>

  <div class="card" >
    <div class="card-body">
      <div class="container">
        <div class="row" style="align: right!important; padding-top:20px">
              <div class="col-sm-5"></div>
              <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Terms of Services</p></div>
              <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Privacy Policy</p></div>
              <div class="col-sm-3"><p style="font-size: 12px; color: #7a7a7a">Copyright 2021, WeFarmers</p></div>
        </div>
      </div>
    </div>
  </div>

  <!--code ends here-->
  <?php require('includes/bootstrap_js.inc.php'); ?>
</body>

</html>