<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/farmer_registration.css"> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <?php require('includes/bootstrap_link.inc.php'); ?> 
  <title>Registration form</title>
</head>

<body>
  
  <header>
    <nav class="navbar fixed-top" style="background-color: #aa207f; padding:0px;">
      <div class="container">
        <div>
          <a class="navbar-brand" href="index.php" style="color: White;">
            <h1 class="header-logo"><strong>WeFarmers</strong></h1>
            <h1 class="header-logo">Seller Central</h1>
          </a>
        </div>
        <div>
          <a href="login.php" class="btn btn-default1">Login</a>
        </div>
      </div>
    </nav>
  </header>
  
  <div class="container-fluid main" id="registration-page-content">
    <div class="row">
      <div class="col-sm">
        <img src="images/greenleaves.png" class="img-fluid" alt="green leaves" id="reg_leaves">
      </div>
      <div class="col-sm">
        <div class="col-md-10 border rounded form" style="border: 2px solid #aa207f!important;">
          <form action = "insert.php" method = "POST">

                

                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                      <input type="Name" class="form-control" id = "name" name = "name" 
                      placeholder="Enter Full Name as per Aadhar" title="Name should contain Alphabets only" 
                      pattern="^[A-Za-z -]+$" required>
                    </div>
                  </div>
                </div>
                

                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <select class = "form-control col-12" id = "gender" name = "gender" 
                      title="Please select valid Gender" required>
                        <option value = "">Please Select Gender</option>
                        <option value = "Male">Male</option>
                        <option value = "Female">Female</option>
                        <option value = "Transgender">Transgender</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <input type="text" class="form-control" id = "mobile_number" name = "mobile_number" 
                      placeholder="Enter 10 digit Mobile No." pattern="[6789][0-9]{9}" 
                      title="Please enter your vaild mobile number" required>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">Date of Birth</span>
                    <input class="form-control" id="dob" name="dob" placeholder="MM/DD/YYYY" 
                    type="DATE" title="Please fill in your Date of Birth" required/>
                </div>
                </div>

                <div class="row">
                  <div class="col-sm-12">
                    <div class="form-group">
                      <input type="text" class="form-control" id = "user_id" name = "user_id" 
                      placeholder="Create Username" pattern="[a-zA-Z0-9]+" 
                      title="Username may contain Alphabets or Numeric Characters." minlength="6" 
                      maxlength="20" required>
                    </div>
                  </div>
                </div>

                <div class="row">
                  
                  <div class="col-sm">
                    <div class="form-group">
                      <input type="password" id = "password" name = "password" class="form-control" 
                      aria-describedby="passwordHelpBlock" placeholder="Create Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
                      title="Password must contain minimum 8 characters, including minimum one Alphabet 
                      (one uppercase and one lowercase), one Numeric and one Special Character." 
                      oninput="setPasswordConfirmValidity();" required>
                    </div>
                  </div>
                  <div class="col-sm">
                    <div class="form-group">
                      <input type="password" class="form-control" id = "cpassword" name = "cpassword" 
                      placeholder="Confirm Password" title="The input must match the above typed Password." 
                      oninput="setPasswordConfirmValidity();" required>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-sm">
                    <div class="form-group">
                      <div class="d-grid gap-2">
                        <button class="btn btn-block btn-default4" style="margin-left:0; margin-top: 20px;" type="submit" name="submit">Register Now</button>
                      </div>
                    </div>
                  </div>
                </div>

          </form>
        </div>
        <div class="col-md-4"></div>
      </div>
    </div>
  </div>
  
  <div class="card" >
    <div class="card-body">
      <div class="container">
        <div class="row" style="align: right!important; padding-top:20px">
              <div class="col-sm-5"></div>
              <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Terms of Services</p></div>
              <div class="col-sm-2"><p style="font-size: 12px; color: #7a7a7a">Privacy Policy</p></div>
              <div class="col-sm-3"><p style="font-size: 12px; color: #7a7a7a">Copyright 2021, WeFarmers</p></div>
        </div>
      </div>
    </div>
  </div>

  <script>
      function setPasswordConfirmValidity(str) {
          const password1 = document.getElementById('password');
          const password2 = document.getElementById('cpassword');
  
          if (password1.value === password2.value) {
               password2.setCustomValidity('');
          } else {
              password2.setCustomValidity('Passwords must match');
          }
          console.log('password2 customError ', document.getElementById('cpassword').validity.customError);
          console.log('password2 validationMessage ', document.getElementById('cpassword').validationMessage);
      }
    </script>

  <?php require('includes/bootstrap_js.inc.php'); ?>

</body>

</html>